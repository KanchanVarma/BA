app.config(function ($stateProvider, $urlRouterProvider, $locationProvider) {
    $urlRouterProvider.otherwise('/login');
    $stateProvider.state('charts', {
        //url: '/charts/{id}',
        url: '/charts',
        templateUrl: 'templates/charts/charts.html',
        controller: 'ChartsCtrl'
    }).state('login', {
        url: '/login',
        templateUrl: 'templates/login/login.html',
        controller: 'LoginCtrl'
    }).state('login-params', {
        url: '/login/:email/:password',
        templateUrl: 'templates/login/login.html',
        controller: 'LoginCtrl'
    }).state('register', {
        url: '/register',
        templateUrl: 'templates/login/register.html',
        controller: 'RegisterCtrl'
    }).state('dashboard', {
        url: '/dashboard',
        templateUrl: 'templates/dashboard/dashboard.html',
        controller: 'DashboardCtrl'
    }).state('reports', {
        url: '/reports',
        templateUrl: 'templates/reports/view-reports.html',
        controller: 'ReportsCtrl'
    });
    // $locationProvider.html5Mode(true);
});
