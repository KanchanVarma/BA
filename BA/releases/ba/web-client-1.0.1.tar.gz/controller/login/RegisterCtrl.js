/**
 * Created by rohit on 19/2/17.
 */
app.controller("RegisterCtrl", function ($scope, Masters, $stateParams, $state, $location, $rootScope) {
    console.log("Register invoked");
        $scope.signUp = function () {
            if ($('#form2').parsley().validate()) {
            Masters.sendRequest("/api/user/register", {
                email: document.getElementById("txt_email").value,
                password: document.getElementById("txt_password").value,
                confirm_password: document.getElementById("txt_confirm_password").value,
                name: document.getElementById("txt_name").value
            }).then(function (response) {
                if (response.code === 1) { 

                    alert(response.message);
                }
                else {
                    alert(response.message);
                }
            })
        };
    }
});