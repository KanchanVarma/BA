app.controller("LoginCtrl", function ($scope, Masters, $stateParams, $state, $location, $rootScope, $timeout, $http, $window) {
  console.log("login invoked");
  setTimeout(function () {
    document.getElementById("txt_email").focus();
  }, 500);
  clearTimeout(window.hb)
  $scope.rememberMeFunction = function () {
    $scope.preLoginData = JSON.parse(localStorage.getItem("userData"))
    if ($scope.preLoginData != undefined) {
      if ($scope.preLoginData['remember']) {
        document.getElementById("txt_email").value = $scope.preLoginData['Email']
        document.getElementById("txt_password").value = window.atob($scope.preLoginData['saltedVal']);
        //$('#remember-box:checked').val("on")
        $('#remember-box').prop('checked', true);
      }
    }
  };

  $scope.initialize = function () {
    if (typeof $stateParams.email != "undefined" && typeof $stateParams.password != "undefined") {
      document.getElementById("txt_email").value = $stateParams.email;
      document.getElementById("txt_password").value = $stateParams.password;
      $scope.localLogin();
    }
  };

  $scope.rememberMeFunction();
  // Login with email and password
  $scope.localLogin = function () {
    if ($('#form1').parsley().validate()) {
      Masters.sendRequest("/api/user/login", {
        email: document.getElementById("txt_email").value,
        password: document.getElementById("txt_password").value
      }).then(function (response) {
        if (response.code === 1) {
          $rootScope.isLoggedIn = localStorage.isLoggedIn = 1;
          response.data['Id'] = response.data['id'];
          $rootScope.userData = response.data;
          $rootScope.userData['remember'] = $('#remember-box').prop('checked');
          if ($rootScope.userData['remember']) {
            $rootScope.userData['saltedVal'] = window.btoa(document.getElementById("txt_password").value);
          }
          localStorage.userData = JSON.stringify($rootScope.userData);
          $http.defaults.headers.common.Authorization = 'Bearer ' + $rootScope.userData.JWToken;
          // if ($rootScope.userData.RoleId == 0) {
          $location.path("/dashboard");
          // } else {
          // $window.location.href = "/cms#/dashboard"
          // }
        } else {
          alert(response.message);
        }
      })
    }
  };

  Masters.get("web/bidder/whoami").then(function (response) {
    if (response["data"]["authenticated"]) {
      $rootScope.userData = {
        "Id": response["data"]["user"]["id"],
        "Name": response["data"]["user"]["name"],
        "RoleId": 0,
      };
      localStorage.userData = JSON.stringify($rootScope.userData);
      $location.path("/dashboard");
    } else {
      window.location.href = "/app"
    }
  });
});
