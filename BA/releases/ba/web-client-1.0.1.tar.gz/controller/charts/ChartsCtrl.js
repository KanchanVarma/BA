app.controller("ChartsCtrl", function ($window, $scope, $rootScope, $http, $timeout, $q, $stateParams, Masters, $state, $filter, DTOptionsBuilder, DTColumnBuilder) {
    $scope.totalColumns = 7;
    $scope.auctionTypes = {
      1: "EF",
      2: "YF",
      3: "ER",
      4: "YR"
    };

    function autoLogout() {
      $scope.logout()
    }

    $window.addEventListener('beforeunload', autoLogout);

    $scope.$on('$destroy', function (e) {
      console.log("called destroy")
      $window.removeEventListener('beforeunload', autoLogout)
    });
    $('html').click(function (e) {
      if (!$(e.target).hasClass('auction-item-bid')) {
        $(".custom-dropdown").hide()
      }
    });

    $scope.historyStickLine = [];

    function validateUser() {
      Masters.get("web/bidder/whoami").then(function (response) {
        if (response["data"]["authenticated"]) {
          $rootScope.userData = {
            "Id": response["data"]["user"]["id"],
            "Name": response["data"]["user"]["name"],
            "RoleId": 0,
          };
          localStorage.userData = JSON.stringify($rootScope.userData);
        } else {
          window.location.href = "/app"
        }
      });
    }

    setInterval(function () {
      validateUser();
    }, 5000);
    validateUser();

    $scope.myFunc = function () {
      var bidPrice = $(this).attr("data-bid-price");
      var auctionType = $(this).attr("data-auction-type");
      if (auctionType == 1 || auctionType == 2) {
        if (this.value > bidPrice) {
          $(this).css('background-color', 'green')
        } else {
          $(this).css('background-color', 'red')
        }
      } else if (auctionType == 1 || auctionType == 2) {
        if (this.value < bidPrice) {
          $(this).css('background-color', 'green')
        } else {
          $(this).css('background-color', 'red')
        }
      }
    };
    var promises = [];
    var hb;

    //window.alert = function() { };
    $scope.auctionType = "";
    $scope.auctionId = parseInt($stateParams.id);
    $scope.remaining_time = "00:00:00";
    $scope.isClickedToShow = false;
    $scope.date = new Date(parseInt('58775f1be8d504a2db9bbc3e'.substring(0, 8), 16) * 1000);
    if (!$rootScope.userData) {
      $rootScope.userData = JSON.parse(localStorage.getItem("userData"));
      if ($rootScope.userData) {
        $http.defaults.headers.common.Authorization = 'Bearer ' + $rootScope.userData.JWToken;
        if ($rootScope.userData.Name) {
          $rootScope.fName = $rootScope.userData.Name.split(" ")[0];
        }
        if ($rootScope.userData.RoleId === 0) {
          $scope.isAdmin = false;
        } else {
          $scope.isAdmin = true;
        }
      }
    } else {
      if ($rootScope.userData.RoleId === 0) {
        $scope.isAdmin = false;
      } else {
        $scope.isAdmin = true;
      }
    }
    if (!$rootScope.userData) {
      $state.go("login")
    }

    $scope.globalUserSelectedList = JSON.parse(localStorage.getItem("userAuctionItemShortlistData"))

    /*    $scope.activeAuctions = JSON.parse(localStorage.getItem("activeAuctions"))
     if (!$scope.activeAuctions) {
     $scope.activeAuctions = [];
     }*/
    $scope.hasBid = false;
    $scope.auctionData = {};
    $scope.isMyhighBid = {};
    $scope.bidInfo = {};
    getDealbook($rootScope.userData['Id']);
    //getOrderBook($rootScope.userData['Id']);
    getOrderHistory($rootScope.userData['Id']);
    if ("WebSocket" in window) {
      // if ($rootScope.userData['JWToken']) {

      var protocol = "ws";
      if (window.location.protocol == "https:") {
        protocol = "wss";
      }

      var ws = new WebSocket(protocol + "://" + window.location.host + "/web/connect");
      // var ws = new WebSocket("ws://" + "172.25.11.39" + ":8083/api/ws/join");

      ws.onopen = function () {
        console.log("Socket has been opened!");

      };
      ws.onerror = function (error) {
        console.log("ERROR");
        console.log(error);
        alert("unable to connect to auction. please check internet and proxy settings");
      }
      // } else {
      //     $state.go("login")
      //     return;
      // }

    } else {
      alert("WebSocket NOT supported by your Browser!");
      return;
    }

    $scope.checkHighestBidder = function (my_price, best_bid) {
      if (typeof my_price != "undefined") {
        if (my_price == best_bid) {
          return "H1";
        }
      }
      return "";
    };

    $scope.isAuction = true;
    ws.onmessage = function (message) {
      listener(JSON.parse(message.data));
    };
    /*    wsTime.onmessage = function (message) {
     var messageObj = JSON.parse(message.data);
     $scope.socketMessage = messageObj['type'];

     if ("SystemTime" == $scope.socketMessage) {
     $scope.serverTime = messageObj['data']['SystemTime'];
     $scope.marqueeDetails = messageObj['data']['TickDetails'];
     $scope.remaining_time = moment($scope.serverTime).format("DD-MM-YYYY hh:mm A");
     $scope.safeApply();
     //debugger;
     clearTimeout(window.hb);
     window.hb = setTimeout(function () {
     //debugger;
     alert("socket connection failed:please check your connection or contact your network administrator");
     ws.close();
     $state.go("login");
     }, 7000);
     }
     }*/
    /* ws.on('disconnect',function() {
     alert("your socket has been disconnected");
     $state.go("dashboard")
     })*/
    ws.onerror = function () {
      alert("unable to connect to auction. please check internet and proxy settings");
      $state.go("dashboard")
    }
    $scope.updateChartData = function (data) {
      $scope.chratingdata = data;
      if ($('#chartReveal').css('display') === 'block' && $('#lineChart').css('display') === 'block') {
        $scope.historyStickLine.push(data[$scope.selectedAuction]);
        $scope.drawCandleStickChart()
      }
    };
//    $scope.getChartingData();

    $scope.safeApply = function (fn) {
      if (this.$root) {
        var phase = this.$root.$$phase;
        if (phase == '$apply' || phase == '$digest') {
          if (fn && (typeof (fn) === 'function')) {
            fn();
          }
        } else {
          this.$apply(fn);
        }
      }
    };


    var slideFlag = true;
    $("#btn-hamburger-menu").on("click", function () {
      if (slideFlag == true) {
        slideFlag = false;
        $(".main-container").animate({"padding-left": "150px"}, 100);
        $("#slide-out").animate({width: "150px"}, 100);
        $("#btn-hamburger-menu i").animate({"padding-left": "104px"}, 100);
        setTimeout(function () {
          $("#slide-out").removeClass("mini");
          $(".brand-logo").css('display', 'block');
          $('.side-nav .collapsible-body li a').css('display', 'block');

        }, 100)
      } else {
        slideFlag = true;
        $(".main-container").animate({"padding-left": "57px"}, 100);
        $("#slide-out").animate({width: "57px"}, 100);
        $("#btn-hamburger-menu i").animate({"padding-left": "0px"}, 100);
        $("#slide-out").addClass("mini");
        $(".brand-logo").css('display', 'none');
        // $('.side-nav .collapsible-body li a').css('display','none');
      }

    });

    function listener(data) {
      var messageObj = data;
      console.log(messageObj);
      // if (messageObj.code == 1) {
      $scope.socketMessage = messageObj['type'];
      if ("connection" == $scope.socketMessage) {
        $scope.shortlistedAI = [];
        for (var key in $scope.globalUserSelectedList) {
          $scope.auctionId = $scope.globalUserSelectedList[key][0]['auction_id']
          for (var m = 0; m < $scope.globalUserSelectedList[key].length; m++) {
            if ($scope.globalUserSelectedList[key][m]['is_shortList']) {
              $scope.shortlistedAI.push($scope.globalUserSelectedList[key][m]['auction_item_id'])
            }
          }
          $scope.joinRoom($scope.shortlistedAI);
        }
        /*            if ($scope.activeAuctions) {
         for (var i = 0; i < $scope.activeAuctions.length; i++) {
         $scope.joinRoom(parseInt($scope.activeAuctions[i]));
         }
         }*/
        // var aucItem = messageObj['data']['auction_item'];
        // var auctionType = messageObj['data']['auction_data']['Auction_type'];
        // $scope.auctionData = populateAuctionDetails(aucItem);
        // $scope.isMyhighBid = populateHighBidDetails(aucItem);
        // $scope.auctionType = $scope.auctionTypes[auctionType];
        // if (1 == auctionType || 3 == auctionType) {
        //     $scope.isEnglish = true;
        // }
        // else {
        //     $scope.isEnglish = false;
        // }
        // sendNotification(messageObj['message'], "green");

      } else if ("auction_finished" === $scope.socketMessage) {
        $(".bid-button").addClass("disabled");
        $scope.isAuction = false;
        sendNotification(messageObj['message'], "red", $scope.socketMessage, $rootScope.userData['Id']);
        //$scope.remaining_time = "00:00:00";
        for (var r = 0; r < $scope.auctionData.length; r++) {
          $scope.auctionData[r]['TimeRemaining'] = "Finished";
        }
        getDealbook($rootScope.userData['Id'])
        getOrderBook($rootScope.userData['Id'])
        getOrderHistory($rootScope.userData['Id'])
        $scope.safeApply()
      } else if ("error" === $scope.socketMessage) {
        $("#custom-loader").hide();
        sendNotification(messageObj['message'], "red", $scope.socketMessage, $rootScope.userData['Id']);
      } else if ("timer" === $scope.socketMessage) {
        if ($scope.allowTimer === true) {


          /* var keys = Object.keys(messageObj.data.Chart_data);
           for (var i = 0; i < keys.length; i++) {
           myMap.set(keys[i], messageObj.data.Chart_data[keys[i]]);
           }
           $scope.candlestickData = messageObj.data.Chart_data; //.auc_1.auction_item_1;
           if ("block" == $(".card-reveal").css("display")) {
           $scope.viewChartSection()
           }*/

          //$scope.updateTimer(messageObj)
          var auctionId = messageObj['data']['auction_id'];
          /*for (var z in messageObj['data']['bid_data']['auc_' + auctionId]) {
           if ($scope.auctionData[z]['TimeRemaining'] != "Finished") {
           if (messageObj['data']['bid_data']['auc_' + auctionId][z].length != 0) {
           var item_id = $scope.auctionData[z]['Id'];
           $scope.auctionData[z]['High_Bid_price'] = convertPaiseToRupees(messageObj['data']['bid_data']['auc_' + auctionId][z][0]['bid_price']);
           if ($scope.auctionData[z]['High_Bid_price'] > $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val()) {
           $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'red');
           } else {
           $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'green')
           }

           if (messageObj['data']['bid_data']['auc_' + auctionId][z][0]['user_id'] == $rootScope.userData['Id']) {
           $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', 'green');
           } else {
           $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', "");
           }

           if ($scope.auctionData[z]['is_autobid']) {
           var bid_price = parseInt($scope.auctionData[z]['High_Bid_price']) + parseInt($scope.auctionData[z]['Tick_size'])
           $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val(bid_price);
           }
           $scope.bidInfo[z] = {}
           for (var y = 0; y < messageObj['data']['bid_data']['auc_' + auctionId][z].length; y++) {
           $scope.bidInfo[z][y] = {};
           $scope.bidInfo[z][y]['Quantity'] = messageObj['data']['bid_data']['auc_' + auctionId][z][y]['quantity'];
           $scope.bidInfo[z][y]['Price'] = convertPaiseToRupees(messageObj['data']['bid_data']['auc_' + auctionId][z][y]['bid_price']);
           }
           notifyUser(messageObj['data']['bid_data']['auc_' + auctionId][z], z);
           }
           }
           }*/
          for (var x in $scope.auctionData) {
            console.log(messageObj['data']['auction_item_timer']);
            if ($scope.auctionData[x]['Id'] === messageObj['data']['auction_item_id']) {
              if ($scope.auctionData[x]['isStarted'] == 1) {
                $scope.auctionData[x]['TimeRemaining'] = calculateRemainingTime(messageObj['data']['auction_item_timer']);
                if (!$scope.isAdmin) {
                  $("#" + x).removeClass("disabled");
                }
              }
            }
          }
          if ($scope.selectedAuction) {
            $scope.bidDetails = $scope.bidInfo[$scope.selectedAuction]
            console.log($scope.bidInfo);
          }
          $scope.safeApply();
        }
      } else if ("user_joined" == $scope.socketMessage) {
        //var aucItem = messageObj['data']['auction_data'];
        var aucItem = messageObj['data'];
        var auction_id = messageObj['data']['auction_id'];
        console.log(messageObj['data']);
        getOrderBook($rootScope.userData['Id']).then(function () {
          $scope.allowTimer = true;
          populateAuctionDetails(aucItem);
          populateHighBidDetails(aucItem);
          //initializeDataToBidTable();
          for (var m in $scope.auctionData) {
            if (messageObj['data']) {
              for (var p = 0; p < messageObj['data'].length; p++) {
                if ($scope.auctionData[m]['Id'] === messageObj['data'][p]['auction_data']['Id']) {
                  $scope.auctionData[m]['isStarted'] = messageObj['data'][p]['auction_data']['IsKnockDown'];
                  if ($scope.auctionData[m]['isStarted'] == 2) {
                    $scope.auctionData[m]['TimeRemaining'] = "Finished";
                  }
                }
                if (messageObj['data'][p]['bid_data']) {
                  callBidData(messageObj['data'][p]['bid_data']);
                }
              }
            }

          }
          //sendNotification("You have Joined The Auction", "green", $scope.socketMessage, $rootScope.userData['Id']);
          setTimeout(function () {
            $("#custom-loader").hide();
            //callBidData(messageObj)
          }, 1000)
        });
      } else if ("auction_item_timer_started" == $scope.socketMessage) {
        if (messageObj['data'].length != 0) {
          $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['isStarted'] = 1;
          if (!$scope.isAdmin) {
            $("#" + 'auction_item_' + messageObj['data']['auction_item_id']).removeClass("disabled");
          }
          console.log("calls");
          //rohits autobid code
          /*if ($scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['is_autobid'] && (parseInt($scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['Base_price']) <= parseInt($scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['max_auto_bid_price']))) {
           var bid_price = parseInt($scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['Base_price']);
           var auction_id = $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['Auction_id'];
           var item_id = $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['Id'];
           $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val(bid_price);
           $scope.submitAutoBid(auction_id, item_id, bid_price);
           }*/
        }

      } else if ("stop_timer" == $scope.socketMessage) {
        $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['isStarted'] = 2;
        $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['TimeRemaining'] = "Finished";
        $("#" + 'auction_item_' + messageObj['data']['auction_item_id']).addClass("disabled");
      } else if ("auction_item_finished" == $scope.socketMessage) {
        if (messageObj['data'].length != 0) {
          $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['isStarted'] = 2;
          $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['TimeRemaining'] = "Finished";
          $scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['ItemStatus'] = messageObj['data']['Item_status'];
          $("#" + 'auction_item_' + messageObj['data']['auction_item_id']).addClass("disabled");
          var auctionId = messageObj['data']['auction_item_id'];
          for (var z in messageObj['data']['bid_data']['auc_' + auctionId]) {
            if ($scope.auctionData[z]['TimeRemaining'] == "Finished") {
              if (messageObj['data']['bid_data']['auc_' + auctionId][z].length != 0) {
                var item_id = $scope.auctionData[z]['Id'];
                $scope.auctionData[z]['High_Bid_price'] = convertPaiseToRupees(messageObj['data']['bid_data']['auc_' + auctionId][z][0]['bid_price']);
                if ($scope.auctionData[z]['High_Bid_price'] > $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val()) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'red');
                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'green')
                }

                if (messageObj['data']['bid_data']['auc_' + auctionId][z][0]['user_id'] == $rootScope.userData['Id']) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', 'green');
                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', "");
                }
              }
              $scope.bidInfo[z] = {}
              for (var y = 0; y < messageObj['data']['bid_data']['auc_' + auctionId][z].length; y++) {
                $scope.bidInfo[z][y] = {};
                $scope.bidInfo[z][y]['Quantity'] = messageObj['data']['bid_data']['auc_' + auctionId][z][y]['quantity'];
                $scope.bidInfo[z][y]['Price'] = convertPaiseToRupees(messageObj['data']['bid_data']['auc_' + auctionId][z][y]['bid_price']);
              }
            }
          }
          if ($scope.selectedAuction) {
            $scope.bidDetails = $scope.bidInfo[$scope.selectedAuction]
            console.log($scope.bidInfo);
          }
          $scope.safeApply()
        }
      } else if ("auction_started" == $scope.socketMessage) {
        $scope.auctionID = messageObj['data']['auction_id'];
        for (var key in $scope.globalUserSelectedList) {
          if ($scope.globalUserSelectedList[key][0]['auction_id'] == messageObj['data']['auction_id']) {
            //$scope.activeAuctions.push(messageObj['data']['auction_id']);
            //localStorage.activeAuctions = JSON.stringify($scope.activeAuctions);
            $scope.joinRoom(parseInt(messageObj['data']['auction_id']));
            console.log("auction details matched");
          }
        }
        // Addede by Renya - Bid confirmation Message
      } else if ("bid" == $scope.socketMessage) {
        sendNotification(messageObj['message'], "green", $scope.socketMessage, $rootScope.userData['Id']);
        //$scope.auctionData['auction_item_' + messageObj['data']['auction_item_id']]['MyBestPrice'] = 9000000;
        for (var key in messageObj['data']) {
          for (var subKey in messageObj['data'][key]) {
            for (var q = 0; q < messageObj['data'][key][subKey].length; q++) {
              if (messageObj['data'][key][subKey][q]['User_id'] == $rootScope.userData['Id']) {
                $scope.auctionData[subKey]['MyBestPrice'] = convertPaiseToRupees(messageObj['data'][key][subKey][q]['Price']);
                $scope.auctionData[subKey]['MyBestQuantity'] = messageObj['data'][key][subKey][q]['Quantity'];
              }
            }
          }
        }
        $scope.safeApply()
      } else if ("outlier" == $scope.socketMessage) {
        sendNotification(messageObj['message'], "red", $scope.socketMessage, $rootScope.userData['Id']);
        for (var key in messageObj['data']) {
          for (var subKey in messageObj['data'][key]) {
            for (var q = 0; q < messageObj['data'][key][subKey]; q++) {
              if (messageObj['data'][key][subKey][q]['User_id'] == $rootScope.userData['Id']) {
                $scope.auctionData[subKey]['MyBestPrice'] = convertPaiseToRupees(messageObj['data'][key][subKey][q]['Price']);
                $scope.auctionData[subKey]['MyBestQuantity'] = messageObj['data'][key][subKey][q]['Quantity'];
              }
            }
          }
        }
      } else if ("bid_data" == $scope.socketMessage) {
        callBidData(messageObj['data']['bid_data']);
        if (messageObj['data']['timer'] && $scope.allowTimer == true) {
          updateAITimer(messageObj['data']['timer']);
        }
        if (messageObj['data']['SystemTime']) {
          updateSystemTime(messageObj['data']['SystemTime']);
        }
        if (Object.keys(messageObj['data']['chart_data']).length > 0) {
          $scope.updateChartData(messageObj['data']['chart_data']);
        }
      } else if ("auction_extended" == $scope.socketMessage) {
        $scope.auctionData["auction_item_" + messageObj['data']['auction_item_id']]['Tick_size'] = convertPaiseToRupees(messageObj['data']['tick_price']);
        $scope.auctionData["auction_item_" + messageObj['data']['auction_item_id']]['Version'] = messageObj['data']['version'];
      } else {
        alert(JSON.stringify(messageObj))
      }
    }

    $scope.loadScripts = function () {

      $("body").on("change", ".bid_price", $scope.myFunc)
      setTimeout(function () {

        jQuery(".perfect-scroll").height(jQuery('.perfect-scroll').height()).perfectScrollbar({
          suppressScrollX: true
        });
        resetScroll();
        // jQuery('.dropdown-button').dropdown({
        //     inDuration: 300,
        //     outDuration: 125,
        //     constrain_width: true, // Does not change width of dropdown to that of the activator
        //     hover: false, // Activate on click
        //     alignment: 'right', // Aligns dropdown to left or right edge (works with constrain_width)
        //     gutter: 0, // Spacing from edge
        //     belowOrigin: true, // Displays dropdown below the button
        //     width: 300
        // });
        $('ul.tabs').tabs();
        $('ul.tabs li').width('');
        $('ul.tabs').tabs('select_tab', 'test1');
        //$scope.drawPieChart();
      }, 0);
    };

    $scope.array = Array.apply(null, {
      length: 50
    }).map(function (value, index) {
      return index + 1;
    });

    $scope.viewChartSection = function (isClickedForOHLC) {
      if ($scope.selectedAuction) {
        $('.card-reveal').css({
          display: 'block'
        }).velocity("stop", false).velocity({
          translateY: '-100%'
        }, {
          duration: 300,
          queue: false,
          easing: 'easeInOutQuad'
        });
        $('ul.tabs').tabs();
        var endDate;
        var startDate;
        if ($scope.dateOption) {
          if ($scope.dateOption !== "custom") {
            startDate = calculateEndDateFilter($scope.dateOption);
            endDate = moment().format("YYYY-MM-DD")
          } else {
            endDate = $("#edatepicker").val();
            startDate = $("#sdatepicker").val();
          }

        } else {
          $scope.dateOption = "week";
          startDate = calculateEndDateFilter($scope.dateOption);
          endDate = moment().format("YYYY-MM-DD")
        }
        if (isClickedForOHLC) {
          getOHLC()
        } else {
          getOHLC();
          getPriceChart()
        }

        function getOHLC() {
          Masters.sendRequest("web/auction/get-history-chart", {
            //product_id: $scope.chratingdata[$scope.selectedAuction]['product_id'],
            product_id: $scope.auctionData[$scope.selectedAuction].Product_Id,
            startDate: JSON.stringify(startDate),
            endDate: JSON.stringify(endDate)
          }).then(function (response) {
            if (response.code == 1) {
              setTimeout(function () {
                $scope.drawCandleStickChart();
              }, 500);

              $scope.stickDetails = [];
              $scope.historyStick = response.data.auctions;
              // var obj = myMap.get($scope.selectedAuction) //$scope.candlestickData[$scope.selectedAuction];
              //$scope.stickDetails.push(obj);
              //for (var index = 0; index < $scope.chratingdata.length; index++) {
              if (typeof $scope.chratingdata != 'undefined') {
                $scope.stickDetails.push($scope.chratingdata);
              }
            } else {
              Materialize.toast("No OHLC Data found", 5000, 'red rounded');
            }
          });
        }

        function getPriceChart() {
          Masters.sendRequest("web/auction/get-line-chart", {
            //product_id: $scope.chratingdata[$scope.selectedAuction]['product_id'],
            product_id: $scope.auctionData[$scope.selectedAuction].Product_Id,
          }).then(function (response) {
            if (response.code == 1) {
              setTimeout(function () {
                $scope.drawCandleStickChart();
              }, 500);

              $scope.historyStickLine = response.data.auctions;
              // var obj = myMap.get($scope.selectedAuction) //$scope.candlestickData[$scope.selectedAuction];
              //$scope.stickDetails.push(obj);
              //for (var index = 0; index < $scope.chratingdata.length; index++) {
              if (typeof $scope.chratingdata != 'undefined') {
                $scope.historyStickLine.push($scope.chratingdata[$scope.selectedAuction]);
              }
            } else {
              Materialize.toast("No Price Graph Data found for this product", 5000, 'red rounded');
            }
          });
        }


        //}

        //return false;

        var data = {
          labels: ["JAN", "FEB", "MAR", "APR", "MAY", "JUNE", "JULY"],
          datasets: [{
            label: "First dataset",
            fillColor: "rgba(128, 222, 234, 0.6)",
            strokeColor: "#ffffff",
            pointColor: "#00bcd4",
            pointStrokeColor: "#ffffff",
            pointHighlightFill: "#ffffff",
            pointHighlightStroke: "#ffffff",
            data: [1, 5, 2, 4, 8, 5, 8]
          },
            {
              label: "Second dataset",
              fillColor: "rgba(128, 222, 234, 0.3)",
              strokeColor: "#80deea",
              pointColor: "#00bcd4",
              pointStrokeColor: "#80deea",
              pointHighlightFill: "#80deea",
              pointHighlightStroke: "#80deea",
              data: [6, 2, 9, 2, 5, 10, 4]
            }
          ]
        };


        var nReloads = 0;
        var min = 1;
        var max = 10;
        var l = 0;
        var trendingLineChart;

        /*trendingLineChart = document.getElementById("trending-line-chart").getContext("2d");

         window.trendingLineChart = new Chart(trendingLineChart).Line(data, {
         scaleShowGridLines: true, ///Boolean - Whether grid lines are shown across the chart
         scaleGridLineColor: "rgba(255,255,255,0.4)", //String - Colour of the grid lines
         scaleGridLineWidth: 1, //Number - Width of the grid lines
         scaleShowHorizontalLines: true, //Boolean - Whether to show horizontal lines (except X axis)
         scaleShowVerticalLines: false, //Boolean - Whether to show vertical lines (except Y axis)
         bezierCurve: true, //Boolean - Whether the line is curved between points
         bezierCurveTension: 0.4, //Number - Tension of the bezier curve between points
         pointDot: true, //Boolean - Whether to show a dot for each point
         pointDotRadius: 5, //Number - Radius of each point dot in pixels
         pointDotStrokeWidth: 2, //Number - Pixel width of point dot stroke
         pointHitDetectionRadius: 20, //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
         datasetStroke: true, //Boolean - Whether to show a stroke for datasets
         datasetStrokeWidth: 3, //Number - Pixel width of dataset stroke
         datasetFill: true, //Boolean - Whether to fill the dataset with a colour
         animationSteps: 60, // Number - Number of animation steps
         animationEasing: "easeOutQuart", // String - Animation easing effect
         tooltipTitleFontFamily: "'Roboto','Helvetica Neue', 'Helvetica', 'Arial', sans-serif", // String - Tooltip title font declaration for the scale label
         scaleFontSize: 12, // Number - Scale label font size in pixels
         scaleFontStyle: "normal", // String - Scale label font weight style
         scaleFontColor: "#000", // String - Scale label font colour
         tooltipEvents: ["mousemove", "touchstart", "touchmove"], // Array - Array of string names to attach tooltip events
         tooltipFillColor: "rgba(255,255,255,0.8)", // String - Tooltip background colour
         tooltipTitleFontFamily: "'Roboto','Helvetica Neue', 'Helvetica', 'Arial', sans-serif", // String - Tooltip title font declaration for the scale label
         tooltipFontSize: 12, // Number - Tooltip label font size in pixels
         tooltipFontColor: "#000", // String - Tooltip label font colour
         tooltipTitleFontFamily: "'Roboto','Helvetica Neue', 'Helvetica', 'Arial', sans-serif", // String - Tooltip title font declaration for the scale label
         tooltipTitleFontSize: 14, // Number - Tooltip title font size in pixels
         tooltipTitleFontStyle: "bold", // String - Tooltip title font weight style
         tooltipTitleFontColor: "#000", // String - Tooltip title font colour
         tooltipYPadding: 8, // Number - pixel width of padding around tooltip text
         tooltipXPadding: 16, // Number - pixel width of padding around tooltip text
         tooltipCaretSize: 10, // Number - Size of the caret on the tooltip
         tooltipCornerRadius: 6, // Number - Pixel radius of the tooltip border
         tooltipXOffset: 10, // Number - Pixel offset from point x to tooltip edge
         responsive: true
         });*/

        function update() {
          nReloads++;

          var x = Math.floor(Math.random() * (max - min + 1)) + min;
          var y = Math.floor(Math.random() * (max - min + 1)) + min;
          window.trendingLineChart.addData([x, y], data.labels[l]);
          window.trendingLineChart.removeData();
          l++;
          if (l == data.labels.length) {
            l = 0;
          }
        }

        //setInterval(update, 3000);
      } else {
        Materialize.toast("Please select an auction", 3000, 'red rounded');
      }
    };

    /*  $scope.drawCandleStickChart = function () {

     var margin = {
     top: 20,
     right: 20,
     bottom: 30,
     left: 50
     },
     width = $("#trending-line-chart").width() - margin.left - margin.right,
     height = $("#trending-line-chart").height() - margin.top - margin.bottom;

     var parseDate = d3.timeParse("%Y-%m-%d") //d3.timeParse("%d-%b-%y");

     var x = techan.scale.financetime()
     .range([0, width]);

     var y = d3.scaleLinear()
     .range([height, 0]);

     var candlestick = techan.plot.candlestick()
     .xScale(x)
     .yScale(y);

     var xAxis = d3.axisBottom()
     .scale(x);

     var yAxis = d3.axisLeft()
     .scale(y);
     $("#trending-line-chart").html("");
     var svg = d3.select("#trending-line-chart").append("svg")
     .attr("width", width + margin.left + margin.right)
     .attr("height", height + margin.top + margin.bottom)
     .append("g")
     .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

     //d3.csv("static/web/controller/charts/data.csv", function (error, data) {
     //d3.csv("static/web/controller/charts/data.csv", function (error, data) {
     /!*data=$scope.candlestickData;
     var Date="01-Jun-14";*!/
     //data = $scope.stickDetails;
     //var data = [];
     var data = [{
     "AuctionId": 18,
     "ClearingPrice": 319,
     "Date": "2017-10-31",
     "HBP": 419,
     "LossingBids": 2,
     "LowestPrice": 220,
     "ProductId": 1,
     "WinnigBids": 1
     }, /!*{
     "AuctionId": 18,
     "ClearingPrice": 219,
     "Date": "2017-10-30",
     "HBP": 419,
     "LossingBids": 0,
     "LowestPrice": 119,
     "ProductId": 1,
     "WinnigBids": 1
     },{
     "AuctionId": 18,
     "ClearingPrice": 249,
     "Date": "2017-10-29",
     "HBP": 349,
     "LossingBids": 0,
     "LowestPrice": 219,
     "ProductId": 1,
     "WinnigBids": 1
     },{
     "AuctionId": 18,
     "ClearingPrice": 289,
     "Date": "2017-10-26",
     "HBP": 589,
     "LossingBids": 0,
     "LowestPrice": 249,
     "ProductId": 1,
     "WinnigBids": 1
     },{
     "AuctionId": 18,
     "ClearingPrice": 329,
     "Date": "2017-10-25",
     "HBP": 429,
     "LossingBids": 0,
     "LowestPrice": 229,
     "ProductId": 1,
     "WinnigBids": 1
     }*!/];


     var accessor = candlestick.accessor();

     data = data.slice(0, 200).map(function (d) {
     return {
     date: parseDate(d.Date),
     open: +d.ClearingPrice,
     high: +d.HBP,
     low: +d.LowestPrice,
     close: +d.LowestPrice
     };
     }).sort(function (a, b) {
     return d3.ascending(accessor.d(a), accessor.d(b));
     });
     svg.append("g")
     .attr("class", "candlestick");

     svg.append("g")
     .attr("class", "x axis")
     .attr("transform", "translate(0," + height + ")");

     svg.append("g")
     .attr("class", "y axis")
     .append("text")
     .attr("transform", "rotate(-90)")
     .attr("y", 6)
     .attr("dy", ".71em")
     .style("text-anchor", "end")
     .text("Price");

     svg.append("g")
     .attr("class", "volume")
     .attr("clip-path", "url(#clip)");


     var context = svg.append("g")
     .attr("class", "context")
     .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


     context.append("g")
     .attr("class", "close");

     svg.append("g")
     .attr("class", "volume axis");

     var xScale = d3.scaleBand()
     .domain(d3.range(0, data.length))
     .range([0, width], 0.05);


     var yScale = d3.scaleLinear()
     .domain([0, d3.max(data)])
     .range([0, height]);

     // Data to display initially
     //draw(data.slice(0, data.length));
     x.domain(data.map(candlestick.accessor().d));
     y.domain(techan.scale.plot.ohlc(data, candlestick.accessor()).domain());

     svg.selectAll("g.candlestick").datum(data).call(candlestick);

     svg.selectAll("g.candlestick")
     .on("mouseover", hoverData)
     /!*(function (d) {

     var xPosition = parseFloat(d3.select(this).attr("x")) + xScale.bandwidth() / 2;
     var yPosition = parseFloat(d3.select(this).attr("y")) / 2 + height / 2;
     d3.select("#tooltip")
     .style("left", xPosition + "px")
     .style("top", yPosition + "px")
     .select("#value")
     .text(d);
     d3.select("#tooltip").classed("hidden", false);
     })()*!/
     .on("mouseout", function () {
     d3.select("#tooltip").classed("hidden", true);
     });

     svg.selectAll("g.x.axis").call(xAxis);
     svg.selectAll("g.y.axis").call(yAxis);

     function hoverData(d, i) {
     console.log(i);
     }

     // Only want this button to be active if the data has loaded

     /!*d3.select("button").on("click", function () {
     //draw(data);
     x.domain(data.map(candlestick.accessor().d));
     y.domain(techan.scale.plot.ohlc(data, candlestick.accessor()).domain());

     svg.selectAll("g.candlestick").datum(data).call(candlestick);
     svg.selectAll("g.x.axis").call(xAxis);
     svg.selectAll("g.y.axis").call(yAxis);
     }).style("display", "inline");*!/

     //});

     function draw(data) {
     x.domain(data.map(candlestick.accessor().d));
     y.domain(techan.scale.plot.ohlc(data, candlestick.accessor()).domain());

     svg.selectAll("g.candlestick").datum(data).call(candlestick);
     svg.selectAll("g.x.axis").call(xAxis);
     svg.selectAll("g.y.axis").call(yAxis);
     }
     //});
     };*/

    $scope.drawCandleStickChart = function () {
      google.charts.load('current', {'packages': ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      google.charts.setOnLoadCallback(drawLineChart);
      var margin = {
        top: 20,
        right: 10,
        bottom: 30,
        left: 50
      }
      var width = $("#trending-line-chart").width() - margin.left - margin.right;
      var height = $("#trending-line-chart").height() - margin.top - margin.bottom;
      var dataArray = [];
      $("#trending-line-chart").html("");
      $("#trending-candle-chart").html("");

      function drawLineChart() {
        var dataLine = new google.visualization.DataTable();
        dataLine.addColumn('datetime', 'Date');
        dataLine.addColumn('number');
        dataLine.addColumn({type: 'string', role: 'tooltip'});
        for (var z = 0; z < $scope.historyStickLine.length; z++) {
          dataLine.addRow();
          dataLine.setValue(z, 0, new Date($scope.historyStickLine[z].date));
          dataLine.setValue(z, 1, convertPaiseToRupees($scope.historyStickLine[z].hbp));
          dataLine.setValue(z, 2, "Date : " + moment($scope.historyStickLine[z].date).format('MMMM Do YYYY, h:mm:ss a') +
            "\n open :" + convertPaiseToRupees($scope.historyStickLine[z].clearingprice) +
            "\n high :" + convertPaiseToRupees($scope.historyStickLine[z].hbp) +
            "\n low : " + convertPaiseToRupees($scope.historyStickLine[z].lowestprice) +
            "\n close : " + convertPaiseToRupees($scope.historyStickLine[z].hbp) +
            "\n Losing Bids : " + $scope.historyStickLine[z].lossingbids +
            "\n Winning Bids : " + $scope.historyStickLine[z].winnigbids);
        }
        var optionsLine = {
          'legend': 'none',
          'width': 950,
          'height': 450,
          // bar: {groupWidth: '50%'}, // Remove space between bars.
          candlestick: {
            fallingColor: {strokeWidth: 0, fill: '#a52714'}, // red
            risingColor: {strokeWidth: 0, fill: '#0f9d58'}   // green
          },
          bar: {groupWidth: '100%'}, // Remove space between bars.
          'vAxis': {'title': 'Price in Rupees'},
          'hAxis': {
            gridlines: {
              count: -1,
              units: {
                days: {format: ['MMM dd']},
                hours: {format: ['HH:mm', 'ha']},
              }
            },
          },
          pointSize: 2,
          pointShape: 'square'

        };
        var chartLine = new google.visualization.LineChart(document.getElementById("trending-line-chart"));
        chartLine.draw(dataLine, optionsLine);
      }

      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Date');
        data.addColumn('number');
        data.addColumn('number');
        data.addColumn('number');
        data.addColumn('number');
        data.addColumn({type: 'string', role: 'tooltip'});
        if ($scope.historyStick) {
          for (var z = 0; z < $scope.historyStick.length; z++) {
            data.addRow();
            data.setValue(z, 0, $scope.historyStick[z].date.substring(0, 10));
            data.setValue(z, 2, convertPaiseToRupees($scope.historyStick[z].clearingprice));
            data.setValue(z, 3, convertPaiseToRupees($scope.historyStick[z].hbp));
            data.setValue(z, 1, convertPaiseToRupees($scope.historyStick[z].lowestprice));
            data.setValue(z, 4, convertPaiseToRupees($scope.historyStick[z].hbp));
            data.setValue(z, 5, "Date : " + $scope.historyStick[z].date.substring(0, 10) +
              "\n open :" + convertPaiseToRupees($scope.historyStick[z].clearingprice) +
              "\n high :" + convertPaiseToRupees($scope.historyStick[z].hbp) +
              "\n low : " + convertPaiseToRupees($scope.historyStick[z].lowestprice) +
              "\n close : " + convertPaiseToRupees($scope.historyStick[z].hbp) +
              "\n Losing Bids : " + $scope.historyStick[z].lossingbids +
              "\n Winning Bids : " + $scope.historyStick[z].winnigbids);
          }
        }

        for (var x = 0; x < $scope.stickDetails.length; x++) {
          /*dataArray.push([$scope.stickDetails[x][$scope.selectedAuction].Date,
           convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].ClearingPrice),
           convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].HBP),
           convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].LowestPrice),
           convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].LowestPrice),"HELLO"]);
           //dataArray.push(['Mon', 20, 28, 38, 45]);*/
          if ($scope.stickDetails[x][$scope.selectedAuction]) {
            data.addRow();
            data.setValue(x, 0, $scope.stickDetails[x][$scope.selectedAuction].date.substring(0, 10));
            data.setValue(x, 2, convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].clearingprice));
            data.setValue(x, 3, convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].hbp));
            data.setValue(x, 1, convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].lowestprice));
            data.setValue(x, 4, convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].hbp));
            data.setValue(x, 5, "Date : " + $scope.stickDetails[x][$scope.selectedAuction].date +
              "\n open :" + convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].clearingprice) +
              "\n high :" + convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].hbp) +
              "\n low : " + convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].lowestprice) +
              "\n close : " + convertPaiseToRupees($scope.stickDetails[x][$scope.selectedAuction].hbp) +
              "\n Losing Bids : " + $scope.stickDetails[x][$scope.selectedAuction].lossingbids +
              "\n Winning Bids : " + $scope.stickDetails[x][$scope.selectedAuction].winnigbids);
          }
        }


        var options = {
          'legend': 'none',
          'width': 950,
          'height': 450,
          // bar: {groupWidth: '50%'}, // Remove space between bars.
          candlestick: {
            fallingColor: {strokeWidth: 0, fill: '#a52714'}, // red
            risingColor: {strokeWidth: 0, fill: '#0f9d58'}   // green
          },
          //bar: { groupWidth: '100%' }, // Remove space between bars.
          'vAxis': {'title': 'Price in Rupees'},
          'hAxis': {
            direction: -1,
            slantedText: true,
            slantedTextAngle: 45 // here you can even use 180
          }

        };

        var chart = new google.visualization.CandlestickChart(document.getElementById("trending-candle-chart"));

        chart.draw(data, options);
      }
    };

    function calculateEndDateFilter(date) {
      var finalDate;
      if (date === "week") {
        finalDate = moment().subtract(7, 'days').startOf('day').format("YYYY-MM-DD");
      } else if (date === "2week") {
        finalDate = moment().subtract(14, 'days').startOf('day').format("YYYY-MM-DD");
      } else if (date === "month") {
        finalDate = moment().subtract(30, 'days').startOf('day').format("YYYY-MM-DD");
      } else if (date === "3months") {
        finalDate = moment().subtract(90, 'days').startOf('day').format("YYYY-MM-DD");
      }

      return finalDate
    }

    $scope.drawPieChart = function () {
      var pieData = [{
        value: 35,
        color: "#3F9F3F"
      },
        {
          value: 35,
          color: "#03a9f4"
        },
        {
          value: 25,
          color: "#9b72b5"
        },
        {
          value: 5,
          color: "#e22a43"
        }
      ];

      var myPie = new Chart(document.getElementById("chart").getContext("2d")).Doughnut(pieData, {
        percentageInnerCutout: 70
      });
    };


    $scope.rightSectionFlag = false;
    $scope.toggleRightSection = function () {
      $scope.rightSectionFlag = ($scope.rightSectionFlag == true ? false : true);
      resetScroll();
    };
    $scope.bottomSectionFlag = false;
    $scope.toggleBottomSection = function () {
      $scope.bottomSectionFlag = ($scope.bottomSectionFlag == true ? false : true);
      resetScroll();
    };

    function resetScroll() {
      setTimeout(function () {
        jQuery('.perfect-scroll').perfectScrollbar('destroy').css({
          'height': ''
        }).height(jQuery('.perfect-scroll').height()).perfectScrollbar({
          suppressScrollX: true
        });
      }, 350)
    }

    $scope._currentDropDown = {};
    $scope.openDropDown = function (auction_id, item_id, event, row_no) {
      $(".custom-dropdown").hide();
      $(".d" + item_id).show();
      $scope._currentDropDown = {
        auction_id: auction_id,
        item_id: item_id,
        event: event,
        row_no: row_no
      };
      console.log(event);
      console.log($scope._currentDropDown);
    };

    $scope.submitXBid = function (highest_bid_price, base_price, tick_size, x, item_id) {
      console.log(x);
      console.log(tick_size);
      console.log(highest_bid_price + (tick_size * x));
      console.log($($scope._currentDropDown.event).parents('.active'));

      var con = confirm("Are you sure you want to bid?");
      if (!con) {
        return;
      }
      let price = (typeof highest_bid_price == "undefined" ? base_price : highest_bid_price)
      $(".bp" + item_id).val((price + (tick_size * x)))
      $scope.submitBid($scope._currentDropDown.auction_id, $scope._currentDropDown.item_id,
        $scope._currentDropDown.event, $scope._currentDropDown.row);
      $(".custom-dropdown").hide();
    };

    $scope.submitBid = function (auction_id, item_id, event, row_no) {
      var $el = $(event.target);
      if (!$el.hasClass('disabled')) {
        if ($scope.isAuction) {
          // var con = confirm("Are you sure you want to bid?");
          // if (!con) {
          //   return;
          // }
          if ($(event.currentTarget).parents('.active').find('.bid_quantity').val() > $scope.auctionData["auction_item_" + item_id]["Max_bq"] || $(event.currentTarget).parents('.active').find('.bid_quantity').val() > $scope.auctionData["auction_item_" + item_id]["Quantity"]) {
            //var r = confirm("bid qty is greater than max bid qty, bid will be sent for manual matching");
            $("#modal1Prompt").openModal({
              dismissible: false
            });
            $scope.alertError = "bid qty is greater than max bid qty, bid will be sent for manual matching";
            $scope.outlierConfirm = function () {
              console.log(auction_id);
              console.log(item_id);
              var bid_quantity = ($scope.isEnglish == true ? $scope.auctionData["auc_" + item_id]["Quantity"] : $(event.currentTarget).parents('.active').find('.bid_quantity').val());
              $scope.row_no = row_no;
              var bid_price = convertRupeesToPaise($(event.currentTarget).parents('.active').find('.bid_price').val());
              ws.send(JSON.stringify({
                "type": "bid",
                "data": {
                  "User_id": $rootScope.userData['Id'],
                  "Auc_sess_id": parseInt(auction_id),
                  "Auction_id": parseInt(item_id),
                  "Quantity": parseInt(bid_quantity),
                  "Price": parseInt(bid_price),
                  "Version": $scope.auctionData["auction_item_" + item_id]["Version"]
                }
              }));
              /*console.log( ws.send(JSON.stringify({
               "type": "bid",
               "data": {
               "User_id": $rootScope.userData['Id'],
               "Auc_sess_id": parseInt(auction_id),
               "Auction_id": parseInt(item_id),
               "Quantity": parseInt(bid_quantity),
               "Price": parseInt(bid_price)
               }
               })));*/
              $("#modal1Prompt").closeModal();

            }
            $scope.outlierCancel = function () {
              Materialize.toast("bid canceled", 3000, 'red rounded');
              $("#modal1Prompt").closeModal();
            }
          } else {
            console.log(auction_id);
            console.log(item_id);
            var bid_quantity = ($scope.isEnglish == true ? $scope.auctionData["auc_" + item_id]["Quantity"] : $(event.currentTarget).parents('.active').find('.bid_quantity').val());
            $scope.row_no = row_no;
            var bid_price = convertRupeesToPaise($(event.currentTarget).parents('.active').find('.bid_price').val());
            ws.send(JSON.stringify({
              "type": "bid",
              "data": {
                "User_id": $rootScope.userData['Id'],
                "Auc_sess_id": parseInt(auction_id),
                "Auction_id": parseInt(item_id),
                "Quantity": parseInt(bid_quantity),
                "Price": parseInt(bid_price),
                "Version": $scope.auctionData["auction_item_" + item_id]["Version"]
              }
            }));
          }
        }
        $scope.isMyhighBid["auction_item_" + item_id]['isHighBid'] = false;
      }
    };


    $scope.submitAutoBid = function (auction_id, item_id, bidPrice) {
      if ($scope.isAuction) {

        var bid_quantity = ($scope.isEnglish == true ? $scope.auctionData["auc_" + item_id]["Quantity"] : $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_quantity').val());
        var bid_price = bidPrice;
        ws.send(JSON.stringify({
          "type": "bid",
          "data": {
            "user_id": $rootScope.userData['Id'],
            "auction_id": parseInt(auction_id),
            "auction_item_id": parseInt(item_id),
            "quantity": parseInt(bid_quantity),
            "bid_price": convertRupeesToPaise(parseInt(bid_price))
          }
        }));
      }
      $scope.isMyhighBid["auction_item_" + item_id]['isHighBid'] = false;
    };

    $scope.joinRoom = function (auction_id) {

      ws.send(JSON.stringify({
        "type": "join",
        "data": {
          "user_id": $rootScope.userData['Id'],
          "AuctionItemId": auction_id
        }
      }));

      /*console.log(ws.send(JSON.stringify({
       "type": "join",
       "data": {
       "user_id": $rootScope.userData['Id'],
       "AuctionItemId": auction_id
       }
       })))*/
    };
    $scope.selectedRow = null;
    $scope.go = function (event, index) {
      $scope.isClickedToShow = true;
      $scope.selectedRow = index;
      $scope.selectedAuction = event;
      getProductParams($scope.auctionData[event]['Product_Id'].toString())
      if ($scope.bidInfo) {
        $scope.bidDetails = $scope.bidInfo[event];
      }
      if ($scope.auctionData) {
        $scope.auctionDataDetails = $scope.auctionData[event]
        if ($scope.auctionDataDetails.Auction_type === 2 || $scope.auctionDataDetails.Auction_type === 4) {
          $scope.isEnglishShowHide = true;
        } else {
          $scope.isEnglishShowHide = false;
        }
      }
    }

    function populateAuctionDetails(aucItem) {
      return new Promise(function (f, r) {
        for (var x = 0; x < aucItem.length; x++) {
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id] = {};
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Quantity'] = aucItem[x]['auction_data']['Quantity'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Base_price'] = convertPaiseToRupees(aucItem[x]['auction_data']['Base_price']);
          //$scope.auctionData["auction_item_" + aucIt[x]['auction_data']x].Id]['High_Bid_price'] = aucItem[x]['Base_price'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['High_Bid_price'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Auction_item_name'] = aucItem[x]['auction_data']['Auction_item_name'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Auction_id'] = aucItem[x]['auction_data']['Auction_id'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Auc_id_display'] = aucItem[x]['auction_data']['Auc_id_display'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Id'] = aucItem[x]['auction_data']['Id'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Active'] = aucItem[x]['auction_data']['Active'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Duration'] = aucItem[x]['auction_data']['Duration'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Reserve_price'] = convertPaiseToRupees(aucItem[x]['auction_data']['Reserve_price']);
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Tick_size'] = convertPaiseToRupees(aucItem[x]['auction_data']['Tick_size']);
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Max_price_inc'] = convertPaiseToRupees(aucItem[x]['auction_data']['Max_price_inc']);
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Bid_limit'] = convertPaiseToRupees(aucItem[x]['auction_data']['Bid_limit']);
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Min_bq'] = aucItem[x]['auction_data']['Min_bq'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Weight_per_kg'] = aucItem[x]['auction_data']['Weight_per_kg'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Start_time'] = aucItem[x]['auction_data']['Start_time'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['End_time'] = aucItem[x]['auction_data']['End_time'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Max_bq'] = aucItem[x]['auction_data']['Max_bq'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Auction_type'] = aucItem[x]['auction_data']['Auction_type'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['ShowRP'] = aucItem[x]['auction_data']['Show_rp'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['uniqueID'] = "auction_item_" + aucItem[x]['auction_data'].Id;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['isStarted'] = 0;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['ItemStatus'] = aucItem[x]['auction_data']['Item_status'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Product_Id'] = aucItem[x]['auction_data']['Product_id'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['TimeRemaining'] = "Pending";
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['is_autobid'] = false;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Quantity_tick'] = aucItem[x]['auction_data']['Quantity_tick'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['Version'] = aucItem[x]['auction_data']['Version'];
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['max_auto_bid_price'] = 0;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['MyBestPrice'] = 0;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['MyBestQuantity'] = 0;
          $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['auction_name'] = aucItem[x]['auction_data']['AuctionName'];

          if ($scope.bidBook && $scope.bidBook.length > 0) {
            for (var bb = 0; bb < $scope.bidBook.length; bb++) {
              if ($scope.bidBook[bb].auction_item_id == aucItem[x]['auction_data'].Id) {
                $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['MyBestPrice'] = $scope.bidBook[bb]['bid_price'];
                $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['MyBestQuantity'] = $scope.bidBook[bb]['quantity'];
                break;
              }
            }

          }

          for (var key in $scope.globalUserSelectedList) {
            for (var i = 0; i < $scope.globalUserSelectedList[key].length; i++) {
              if ($scope.globalUserSelectedList[key][i]['is_shortList'] != undefined && $scope.globalUserSelectedList[key][i]['is_shortList'] == true) {
                if ($scope.globalUserSelectedList[key][i]['id'] == aucItem[x]['auction_data']['Id']) {
                  $scope.auctionData["auction_item_" + aucItem[x]['auction_data'].Id]['isShortlisted'] = true;
                }
              }
            }
          }
          //$scope.allAuctionData = angular.copy($scope.auctionData);
          $scope.totalCount = Object.keys($scope.auctionData).length;

          //$scope.auctionData = $scope.auctionData.splice(0,30);

          f(true);
        }
      });
    }

    function populateHighBidDetails(aucItem) {
      //var obj = {};
      for (var z = 0; z < aucItem.length; z++) {
        $scope.isMyhighBid["auction_item_" + aucItem[z]['auction_item_id']] = {};
        $scope.isMyhighBid["auction_item_" + aucItem[z]['auction_item_id']]['isHighBid'] = false;
        $scope.isMyhighBid["auction_item_" + aucItem[z]['auction_item_id']]['ItemName'] = aucItem[z]['auction_data']['Auction_item_name'];
        $scope.isMyhighBid["auction_item_" + aucItem[z]['auction_item_id']]['ItemCode'] = aucItem[z]['auction_data']['Auction_type'];
        //return obj;
      }
    }

    function callBidData(bidData) {

      if (bidData != undefined && Object.keys(bidData).length > 0) {
        for (var z in bidData) {
          if ($scope.auctionData[z]['TimeRemaining'] != "Finished") {
            if (bidData[z].length != 0) {
              var item_id = $scope.auctionData[z]['Id'];
              $scope.auctionData[z]['High_Bid_price'] = convertPaiseToRupees(bidData[z][0]['Price']);
              if (parseInt($scope.auctionData[z]['Auction_type']) == 1 || parseInt($scope.auctionData[z]['Auction_type']) == 2) {
                if ($scope.auctionData[z]['High_Bid_price'] > $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val()) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'red');

                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'green')
                }
                if (bidData[z][0]['User_id'] == $rootScope.userData['Id']) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', 'green');
                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', "");
                }
              } else if (parseInt($scope.auctionData[z]['Auction_type']) == 3 || parseInt($scope.auctionData[z]['Auction_type']) == 4) {
                if ($scope.auctionData[z]['High_Bid_price'] < $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val()) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'red');

                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').css('background-color', 'green')
                }
                if (bidData[z][0]['User_id'] == $rootScope.userData['Id']) {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', 'green');
                } else {
                  $("[data-item-id=" + item_id + "]").parents('.active').find('.high_bid_price').css('background-color', "");
                }
              }
              /*if ($scope.auctionData[z]['is_autobid']) {
               var bid_price = parseInt($scope.auctionData[z]['High_Bid_price']) + parseInt($scope.auctionData[z]['Tick_size'])
               $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val(bid_price);
               }*/
              $scope.bidInfo[z] = {}
              for (var y = 0; y < bidData[z].length; y++) {
                $scope.bidInfo[z][y] = {};
                $scope.bidInfo[z][y]['Quantity'] = bidData[z][y]['Quantity'];
                $scope.bidInfo[z][y]['Price'] = convertPaiseToRupees(bidData[z][y]['Price']);
              }
              notifyUser(bidData[z], z);
            }
          }
        }
      }
    }

    function notifyUser(param, z) {
      if ($scope.isMyhighBid[z]['ItemCode'] != 2 && $scope.isMyhighBid[z]['ItemCode'] != 4) {
        if ($scope.isMyhighBid[z]['isHighBid'] == true && parseInt(param[0].user_id) != $rootScope.userData['Id']) {
          console.log('outbid');
          var message = 'You have been outbid on auction ' + $scope.isMyhighBid[z]["ItemName"];

          sendNotification(message, "black", 'Outbid', $rootScope.userData['Id']);
          $scope.isMyhighBid[z]['isHighBid'] = false;

          if ($scope.auctionData[z]['is_autobid'] && (parseInt($scope.auctionData[z]['Tick_size'] + param[0]['bid_price']) <= parseInt($scope.auctionData[z]['max_auto_bid_price']))) {
            var bid_price = parseInt($scope.auctionData[z]['Tick_size'] + param[0]['bid_price']);
            var auction_id = $scope.auctionData[z]['Auction_id'];
            var item_id = $scope.auctionData[z]['Id'];
            $("[data-item-id=" + item_id + "]").parents('.active').find('.bid_price').val(bid_price);
            $scope.submitAutoBid(auction_id, item_id, bid_price);
          }
        }
        if (param[0].user_id == $rootScope.userData['Id']) {
          $scope.isMyhighBid[z]['isHighBid'] = true;
        }
      }

    }

    function sendNotification(message, color, messageType, userId) {
      Materialize.toast(message, 3000, color + ' rounded');
      //message = message +  " - " +  moment(new Date()).format("DD/MM/YYYY") + " " + moment(new Date().getTime()).format("HH:mm:ss");
      var notificationmessage = message
      var notificationtime = new Date().toDateString() + "  " + new Date().toLocaleTimeString()
      message = new Date().toDateString() + "  " + new Date().toLocaleTimeString() + " - " + message;

      writeToNotificationLog(userId, messageType, message);
      $("#notificationBar").prepend('<li class="notificationBar">\
		    <p class="notification_bar">' + notificationmessage + '</p>\
		    <p class="notification_bar">' + notificationtime + '</p>\
		     <p class="divider"></p>\
	    </li>');
    }

    /*    function heartBeat() {
     alert("socket connection failed:please check conection");
     ws.close();
     $state.go("dashboard");

     }*/
    $scope.goToDashboard = function () {
      ws.close();
      clearTimeout(window.hb);
    }

    $scope.updateTimer = function (obj) {
      if ($scope.isAuction == true) {

        $scope.remaining_time = calculateRemainingTime(obj["data"]["timer"]);
        $scope.safeApply()
      }
    };

    /*function calculateRemainingTime(sec) {

     return moment().startOf('year')
     .seconds(sec)
     .format('HH:mm:ss');


     }*/

    function pad(num) {
      return ("0" + num).slice(-2);
    }

    function calculateRemainingTime(secs) {
      var minutes = Math.floor(secs / 60);
      secs = secs.toFixed(0) % 60;
      var hours = Math.floor(minutes / 60)
      minutes = minutes % 60;
      return pad(hours) + ":" + pad(minutes) + ":" + pad(secs);
    }

    function getOrderHistory(userID) {
      if (userID) {
        Masters.sendRequest("web/bidbook/get-history", {
          user_id: userID
        }).then(function (response) {
          if (response.code === 1) {
            if (response.data.tables != undefined && response.data.tables.length > 0) {
              for (var i = 0; i < response.data.tables.length; i++) {
                response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
              }
              /* var vm = this;
               vm.bidBook = response.data.tables;*/
              $scope.bidBookHist = response.data.tables;
              console.log($scope.bidBookHist)
              //initializeDataToBidTable1()
            }
          } else {
            console.log(response.message);
          }
        })
      }
    }

    function getOrderBook(userID) {
      return new Promise(function (f, r) {
        if (userID) {
          Masters.sendRequest("web/bidbook/get", {
            user_id: userID
          }).then(function (response) {
            if (response.code === 1) {
              if (response.data.tables != undefined && response.data.tables.length > 0) {
                for (var i = 0; i < response.data.tables.length; i++) {
                  response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                  response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                  response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                  response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                  response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                  response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
                }
                /*var vm = this;
                 vm.bidBook = response.data.tables;*/
                $scope.bidBook = response.data.tables;
                console.log($scope.bidBook, "twtwtwtw", moment())
                //asyncUpdateMyBid($scope.bidBook)
                f(true);
                //initializeDataToBidTable1()
              }
            } else {
              console.log(response.message);
              f(false);
            }
          })
        }
      });
    }

    function getDealbook(userID) {
      if (userID) {
        Masters.sendRequest("web/dealbook/get", {
          user_id: userID
        }).then(function (response) {
          if (response.code === 1) {
            if (response.data.tables != undefined && response.data.tables.length > 0) {
              for (var i = 0; i < response.data.tables.length; i++) {
                response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
              }
              $scope.dealBook = response.data.tables;
              console.log($scope.dealBook);
              //initializeDataToBidTable2()
              $scope.safeApply($scope.dealBook);
            }
          } else {
            console.log(response.message);
          }
        })
      }
    }


    $scope.openAutoBidRow = function (item_id) {
      console.log(item_id);
      if (!$('#checkboxBid' + item_id).is(":checked")) {
        $scope.auctionData['auction_item_' + item_id]['is_autobid'] = true;
        $('#textboxBid' + item_id).prop('disabled', false);
      } else {
        $scope.auctionData['auction_item_' + item_id]['is_autobid'] = false;
        $('#textboxBid' + item_id).prop('disabled', true);
      }
    };

    $scope.setMaxValue = function (value) {
      console.log('value');
      console.log(value);
    }


    $("body").on("keyup", ".txt_auto_bid_max", function () {
      $scope.auctionData['auction_item_' + $(this).attr("data-item-id")]['max_auto_bid_price'] = this.value;
    })

    function writeToNotificationLog(userID, MessageType, Message) {
      if (userID) {
        Masters.sendRequest("web/auction/log-notification", {
          message: Message,
          message_type: MessageType,
          user_id: userID
        }).then(function (response) {
          if (response.code === 1) {
            console.log(response.message + " , Message logged")
          } else {
            console.log(response.message);
          }
        })
      }
    }

    /*
     $("body").on("mouseover", "#DataTables_Table_0 tbody td:not(:has(>input))", function (e) {
     var index = $($(this).parent()).attr("data-title-id");
     if($scope.auctionData[index]) {
     $scope.showToolTip({
     "Auction No": $scope.auctionData[index]['Auc_Id_Display'],
     "Start Time": $scope.auctionData[index]['Start_time'],
     "End Time": $scope.auctionData[index]['End_time'],
     "Item Status": $scope.auctionData[index]['ItemStatus']
     }, $(this));


     $(".custom-tooltip").css({
     left: ($(this).position().left) + "px",
     top: ($(this).position().top + ($(".custom-tooltip").height() * 2)) + "px",
     });

     setTimeout(function () {
     $(".custom-tooltip").css({
     opacity: 1
     })
     }, 1000);
     }
     }).on("mouseout", "#DataTables_Table_1 tr", function (e) {
     $(".custom-tooltip").css({
     opacity: 0
     })
     }).on("mousemove", "#DataTables_Table_1 tr", function (e) {
     $(".custom-tooltip").css({
     opacity: 0
     })
     });
     */

    /*    $scope.showToolTip = function (object) {
     var head = "";
     var body = "";
     var html = "";
     /!*html = "<div class='custom-tooltip'>";*!/

     for (var key in object) {
     head += "<th>" + key + "</th>";
     body += "<td>" + object[key] + "</td>";
     }

     html += '<table class=" striped ">';
     html += '<thead>';
     html += head;
     html += '</thead>';
     html += '<body>';
     html += body;
     html += '</body>';
     html += '</table>';
     // html += '</div>';

     $(".custom-tooltip").html(html);
     };*/

    $scope.logout = function () {
      ws.close();
      clearTimeout(window.hb);
      $rootScope.globalUserSelectedList = {};
      //localStorage.clear();
      if ($rootScope.userData) {
        $rootScope.userData.JWToken = "";
        localStorage.userData = JSON.stringify($rootScope.userData);
      }
      $rootScope = $rootScope.$new(true);
      $scope = $scope.$new(true);
      $http.defaults.headers.common.Authorization = '';
      Masters.sendRequest("web/bidder/logout", {}).then(function (response) {
        window.location.href = "/app"
      });
    };


    $scope.RefreshOrderHistory = function () {
      getOrderHistory($rootScope.userData['Id']);
    };
    $scope.RefreshOrderBook = function () {
      getOrderBook($rootScope.userData['Id']);
    };

    $scope.RefreshDealBook = function () {
      getDealbook($rootScope.userData['Id']);
    };
    var language = {
      "sSearch": "",
      "searchPlaceholder": "Search"
    }
//$scope.dtOptions = DTOptionsBuilder.newOptions().withOption('paging',false).withOption('scrollY','300');
    $scope.dtOptions = DTOptionsBuilder.newOptions().withLanguage(language).withOption('paging', false).withOption('scrollY', '380').withOption('order', []);
    /* function convertRupeesToPaise(x) {
     return x * 100;
     }*/

    /*function convertPaiseToRupees(x) {
     return x / 100;
     }*/

    var convertPaiseToRupees = (x) => x / 100;
    var convertRupeesToPaise = (x) => x * 100;

    function getProductParams(id) {
      if (id) {
        Masters.sendRequest("/web/product/load-all-product-params", {
          product_id: id
        }).then(function (response) {
          if (response.code === 1) {
            $scope.productDataParameters = response.data.data;
          } else {
            console.log(response.message);
          }
        })
      }
    }


    $('.notification-collapse').sideNav({
      menuWidth: 280,
      edge: 'right',
    });

    $(".rightside-navigation").on("click", function () {
      $('.notification-collapse').trigger("click");
    })

    function asyncUpdateMyBid(bbook) {
      if (bbook && bbook.length > 0 && $scope.auctionData && $scope.auctionData.length > 0) {
        for (var bb = 0; bb < bbook.length; bb++) {
          for (var key in $scope.auctionData) {
            if ($scope.bidBook[bb].auction_item_id == $scope.auctionData[key].Id) {
              $scope.auctionData[key]['MyBestPrice'] = bbook[bb]['bid_price'];
              $scope.auctionData[key]['MyBestQuantity'] = bbook[bb]['quantity'];
              break;
            }
          }
        }

      }

    }

    /*    var resize= $("#auctionDepth");
     var containerWidth = $("#leftPanel").width();

     $(resize).resizable({
     handles: 'e',
     maxWidth: 450,
     minWidth: 120,
     resize: function(event, ui){
     var currentWidth = ui.size.width;

     // this accounts for padding in the panels +
     // borders, you could calculate this using jQuery
     var padding = 12;

     // this accounts for some lag in the ui.size value, if you take this away
     // you'll get some instable behaviour
     $(this).width(currentWidth);

     // set the content panel width
     $("#auctiondetails").width(containerWidth - currentWidth - padding);
     }
     });*/
    function updateAITimer(timer) {
      for (var x in $scope.auctionData) {
        for (var z in timer) {
          if ($scope.auctionData[x]['uniqueID'] === z) {
            if ($scope.auctionData[x]['isStarted'] == 1) {
              $scope.auctionData[x]['TimeRemaining'] = calculateRemainingTime(timer[z]);
              if (!$scope.isAdmin) {
                $("#" + x).removeClass("disabled");
              }
            }
          }
        }
      }
      if ($scope.selectedAuction) {
        $scope.bidDetails = $scope.bidInfo[$scope.selectedAuction]
        console.log($scope.bidInfo);
      }
      $scope.safeApply();
    }

    function updateSystemTime(time) {

      $scope.serverTime = time;
      //$scope.marqueeDetails = messageObj['data']['TickDetails'];
      $scope.remaining_time = moment($scope.serverTime).format("DD-MM-YYYY hh:mm A");
      $scope.safeApply();
      //debugger;
      console.log("heartbeat received, timeout updated")
      clearTimeout(window.hb);
      window.hb = setTimeout(function () {
        //debugger;
        alert("socket connection failed:please check your connection or contact your network administrator");
        ws.close();
        $state.go("login");
      }, 7000);
    }

    $("#txt_filter").on('keyup', function () {
      if (this.value != "") {
        $('#auctionWatch tbody tr').css({display: 'none'});
        $('#auctionWatch tbody tr:contains("' + this.value.toLowerCase() + '")').css({display: 'table-row'});
      } else {
        $('#auctionWatch tbody tr').css({display: 'table-row'});
      }
    });

  }
).filter('total', function () {
  // return  currentObj[prop];
  return function (arr, prop) {
    return arr.reduce(function (previousValue, currentObj) {
      return previousValue + currentObj[prop];
    }, 0);
  }
})
/*.filter('with', function () {
 return function (items, field) {
 var result = {};
 angular.forEach(items, function (value, key) {
 if (typeof field != "undefined" && field != "") {

 for (var i in value) {
 if (typeof value[i] != "undefined") {
 if (value[i].toString().toLowerCase().search(field) > -1) {
 result[key] = value;
 }
 }
 }
 // if (value === field) {
 //
 // }
 } else {
 result[key] = value;
 }
 });
 return result;
 };
 });*/
