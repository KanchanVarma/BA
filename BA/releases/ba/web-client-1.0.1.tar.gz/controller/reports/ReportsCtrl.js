/**
 * Created by rohit on 19/7/17.
 */
app.controller("ReportsCtrl", function ($scope, Masters, $stateParams, $state, $location, $rootScope, $timeout, DTOptionsBuilder, DTColumnDefBuilder) {

    if (!$rootScope.userData) {
        $rootScope.userData = JSON.parse(localStorage.getItem("userData"));
        if ($rootScope.userData.Name) {
            $rootScope.fName = $rootScope.userData.Name.split(" ")[0];
        }
    } else {
        if ($rootScope.userData.Name) {
            $rootScope.fName = $rootScope.userData.Name.split(" ")[0];
        }
    }


    var slideFlag = true;
    $("#btn-hamburger-menu").on("click", function () {
        if (slideFlag == true) {
            slideFlag = false;
            $(".main-container").animate({"padding-left": "150px"}, 100);
            $("#slide-out").animate({width: "150px"}, 100);
            $("#btn-hamburger-menu i").animate({"padding-left": "100px"}, 100);
            setTimeout(function () {
                $("#slide-out").removeClass("mini");
                $(".brand-logo").css('display', 'block');
                $('.side-nav .collapsible-body li a').css('display', 'block');

            }, 100)
        } else {
            slideFlag = true;
            $(".main-container").animate({"padding-left": "57px"}, 100);
            $("#slide-out").animate({width: "57px"}, 100);
            $("#btn-hamburger-menu i").animate({"padding-left": "0px"}, 100);
            $("#slide-out").addClass("mini");
            $(".brand-logo").css('display', 'none');
            // $('.side-nav .collapsible-body li a').css('display','none');
        }

    });

    $scope.loadScripts = function () {
        setTimeout(function () {

            jQuery(".perfect-scroll").height(jQuery('.perfect-scroll').height()).perfectScrollbar({
                suppressScrollX: true
            });
            resetScroll();
            // jQuery('.dropdown-button').dropdown({
            //     inDuration: 300,
            //     outDuration: 125,
            //     constrain_width: true, // Does not change width of dropdown to that of the activator
            //     hover: false, // Activate on click
            //     alignment: 'right', // Aligns dropdown to left or right edge (works with constrain_width)
            //     gutter: 0, // Spacing from edge
            //     belowOrigin: true, // Displays dropdown below the button
            //     width: 300
            // });
            $('#tabsMenuList').tabs({
                onShow: function (tab) {
                    console.log(tab);
                }
            });
            $('ul.tabs li').width('');
            $('ul.tabs').tabs('select_tab', 'test2');
            //$scope.drawPieChart();
        }, 0);
    };


    console.log($rootScope.fName)
    getDealbook($rootScope.userData['Id']);
    getOrderBook($rootScope.userData['Id']);
    getOrderHistory($rootScope.userData['Id']);
    $scope.RefreshOrderHistory = function () {
        getOrderHistory($rootScope.userData['Id']);
    };
    $scope.RefreshOrderBook = function () {
        getOrderBook($rootScope.userData['Id']);
    };

    $scope.RefreshDealBook = function () {
        getDealbook($rootScope.userData['Id']);
    };


    function getOrderHistory(userID) {
        if (userID) {
            Masters.sendRequest("api/bidbook/get-history-report", {
                user_id: userID
            }).then(function (response) {
                if (response.code === 1) {
                    if (response.data.tables != undefined && response.data.tables.length > 0) {
                        for (var i = 0; i < response.data.tables.length; i++) {
                            response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                            response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                            response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                            response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                            response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                            response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
                        }
                        /* var vm = this;
                         vm.bidBook = response.data.tables;*/
                        $scope.bidBookHist = response.data.tables;
                        console.log($scope.bidBookHist)
                        //initializeDataToBidTable1()
                    }
                } else {
                    console.log(response.message);
                }
            })
        }
    }

    function getOrderBook(userID) {
        return new Promise(function (f, r) {
            if (userID) {
                Masters.sendRequest("api/bidbook/get-report", {
                    user_id: userID
                }).then(function (response) {
                    if (response.code === 1) {
                        if (response.data.tables != undefined && response.data.tables.length > 0) {
                            for (var i = 0; i < response.data.tables.length; i++) {
                                response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                                response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                                response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                                response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                                response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                                response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
                            }
                            /*var vm = this;
                             vm.bidBook = response.data.tables;*/
                            $scope.bidBook = response.data.tables;
                            f(true);
                            //initializeDataToBidTable1()
                        }
                    } else {
                        console.log(response.message);
                    }
                })
            }
        });
    }

    function getDealbook(userID) {
        if (userID) {
            Masters.sendRequest("api/dealbook/get-report", {
                user_id: userID
            }).then(function (response) {
                if (response.code === 1) {
                    if (response.data.tables != undefined && response.data.tables.length > 0) {
                        for (var i = 0; i < response.data.tables.length; i++) {
                            response.data.tables[i]['base_price'] = convertPaiseToRupees(response.data.tables[i]['base_price']);
                            response.data.tables[i]['bid_limit'] = convertPaiseToRupees(response.data.tables[i]['bid_limit']);
                            response.data.tables[i]['max_price_inc'] = convertPaiseToRupees(response.data.tables[i]['max_price_inc']);
                            response.data.tables[i]['reserve_price'] = convertPaiseToRupees(response.data.tables[i]['reserve_price']);
                            response.data.tables[i]['tick_size'] = convertPaiseToRupees(response.data.tables[i]['tick_size']);
                            response.data.tables[i]['bid_price'] = convertPaiseToRupees(response.data.tables[i]['bid_price']);
                        }
                        $scope.dealBook = response.data.tables;
                        console.log($scope.dealBook);
                        //initializeDataToBidTable2()
                        $scope.safeApply($scope.dealBook);
                    }
                } else {
                    console.log(response.message);
                }
            })
        }
    }

    $scope.safeApply = function (fn) {
        if (this.$root) {
            var phase = this.$root.$$phase;
            if (phase == '$apply' || phase == '$digest') {
                if (fn && (typeof (fn) === 'function')) {
                    fn();
                }
            } else {
                this.$apply(fn);
            }
        }
    };

    var language = {
        "sSearch": "",
        "searchPlaceholder": "Search"
    };

    function resetScroll() {
        setTimeout(function () {
            jQuery('.perfect-scroll').perfectScrollbar('destroy').css({
                'height': ''
            }).height(jQuery('.perfect-scroll').height()).perfectScrollbar({
                suppressScrollX: true
            });
        }, 350)
    }


    function convertPaiseToRupees(x) {
        return x / 100;
    }

    function getExportFileName() {

        var fileName = $('#tabsMenuList').find(".active").text().split(' ').join('')+ moment().utc().format("DD-MM-YYYY");

        return fileName
    }

    $scope.dtOptions = DTOptionsBuilder.newOptions().withLanguage(language).withOption('scrollY', '400').withOption('order', [])/*.withButtons([
            {
                extend: 'copy',
                text: '<i class="fa fa-files-o"></i> Copy',
                titleAttr: 'Copy'
            },
            {
                extend: 'print',
                text: '<i class="fa fa-print" aria-hidden="true"></i> Print',
                titleAttr: 'Print'
            },
            {
                extend: 'csvHtml5',
                text: '<i class="fa fa-file-text-o"></i> CSV',
                filename: function () { return getExportFileName();},
                titleAttr: 'CSV'
            }
        ]
    );*/
    ;

    $scope.dtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(3).notSortable()
    ];

});