app.controller("DashboardCtrl", function ($scope, Masters, $state, $timeout, $rootScope, $http, $window) {
  // var leftnav = $(".page-topbar").height();
  // var leftnavHeight = window.innerHeight - leftnav;
  // $('.leftside-navigation').height(leftnavHeight).perfectScrollbar({
  //     suppressScrollX: true
  // });
  //alert()


  Masters.get("web/bidder/whoami").then(function (response) {
    if (response["data"]["authenticated"]) {
      $rootScope.userData = {
        "Id": response["data"]["user"]["id"],
        "Name": response["data"]["user"]["name"],
        "RoleId": 0,
      };
      localStorage.userData = JSON.stringify($rootScope.userData);
    } else {
      window.location.href = "/app"
    }
  });

  $scope.totalColumns = 2;
  //$scope.preShortlist = false;
  $scope.Selectedcount = 0;
  // more change
  clearTimeout(window.hb)
  if ($rootScope.globalUserSelectedList == undefined) {
    $rootScope.globalUserSelectedList = {};
  }
  if (!$rootScope.userData) {
    $rootScope.userData = JSON.parse(localStorage.getItem("userData"));
    if ($rootScope.userData) {
      // $http.defaults.headers.common.Authorization = 'Bearer ' + $rootScope.userData.JWToken;
      if ($rootScope.userData.Name) {
        $rootScope.fName = $rootScope.userData.Name.split(" ")[0];
      }
      if ($rootScope.userData.RoleId === 0) {
        $scope.isAdmin = false;
      } else {
        $scope.isAdmin = true;
      }
    }


  } else {
    if ($rootScope.userData && $rootScope.userData.Name) {
      $rootScope.fName = $rootScope.userData.Name.split(" ")[0];
    }
    if ($rootScope.userData.RoleId === 0) {
      $scope.isAdmin = false;
    } else {
      $scope.isAdmin = true;
    }
  }

  /*if (!$rootScope.userData) {
   $state.go("login")
   }*/

  $scope.current = false;
  $scope.past = false;
  $scope.upcoming = false;
  var slideFlag = true;
  $("#btn-hamburger-menu").on("click", function () {
    if (slideFlag == true) {
      slideFlag = false;
      $(".main-container").animate({"padding-left": "150px"}, 100);
      $("#slide-out").animate({width: "150px"}, 100);
      $("#btn-hamburger-menu i").animate({"padding-left": "104px"}, 100);
      setTimeout(function () {
        $("#slide-out").removeClass("mini");
        $(".brand-logo").css('display', 'block');
        $('.side-nav .collapsible-body li a').css('display', 'block');

      }, 100)
    } else {
      slideFlag = true;
      $(".main-container").animate({"padding-left": "57px"}, 100);
      $("#slide-out").animate({width: "57px"}, 100);
      $("#btn-hamburger-menu i").animate({"padding-left": "0px"}, 100);
      $("#slide-out").addClass("mini");
      $(".brand-logo").css('display', 'none');
      // $('.side-nav .collapsible-body li a').css('display','none');
    }

  });

  /*$scope.getAuctionLists = function () {
      Masters.sendRequest("/api/sockets/get-auction-list", {}).then(function (response) {
          if (response.code === 1) {
              $scope.auctionList = response.data.auctions;
              for (var x = 0; x < $scope.auctionList.length; x++) {
                  //$scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).toNow(true);
                  $scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).fromNow();
              }
              console.log($scope.auctionList)
          } else {

          }
          $timeout($scope.getAuctionLists, 30000);
      });

  }*/

  $scope.getAuctionLists = () => {
    Masters.sendRequest("/web/sockets/get-auction-list", {}).then(function (response) {
      if (response.code === 1) {
        $scope.auctionList = response.data.auctions;
        for (var x = 0; x < $scope.auctionList.length; x++) {
          //$scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).toNow(true);
          $scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).fromNow();
        }
        console.log($scope.auctionList)
      } else {

      }
      //$timeout($scope.getAuctionLists, 30000);
    });
  }
  $scope.getCurrentAuctions = function () {
    Masters.sendRequest("web/auction/get-current-auction", {
      client_id: $rootScope.userData.ClientId,
      user_id: parseInt($rootScope.userData['Id'])
    }).then(function (response) {
      if (response.code === 1) {
        $scope.currentAuctionList = response.data['current'];
        console.log($scope.currentAuctionList)
        if ($scope.currentAuctionList) {
          for (var x = 0; x < $scope.currentAuctionList.length; x++) {
            //$scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).toNow(true);
            $scope.currentAuctionList[x]['countdownTime'] = moment($scope.currentAuctionList[x]['start_time']).fromNow();
          }
          $scope.current = true;
          console.log($scope.currentAuctionList);
        }
        $scope.upcomingAuctionList = response.data.data[2]['upcoming'];
        if ($scope.upcomingAuctionList) {
          for (var x = 0; x < $scope.upcomingAuctionList.length; x++) {
            //$scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).toNow(true);
            $scope.upcomingAuctionList[x]['countdownTime'] = moment($scope.upcomingAuctionList[x]['start_time']).fromNow();
            ;
          }
          console.log($scope.upcomingAuctionList)
          $scope.upcoming = true;
        }

        $scope.pastAuctionList = response.data.data[1]['past'];
        if ($scope.pastAuctionList) {
          for (var x = 0; x < $scope.pastAuctionList.length; x++) {
            $scope.pastAuctionList[x]['countdownTime'] = moment($scope.pastAuctionList[x]['start_time']).fromNow();
          }
          console.log("data");
          $scope.past = true;
        }

        setTimeout(function () {
          createCarousel("slider-two");
          // createCarousel("auctionJcarousel");
          createCarousel("auctionJcarousel2");
        }, 500);
        timer = $timeout($scope.getCurrentAuctions, 30000);

      } else {


      }
      //$timeout($scope.getCurrentAuctions, 30000);
    });
  };

  $scope.goToDashboard = function () {
    window.location.href = "/app";
  }

  /*    $scope.getUpcomingAuction = function () {
          Masters.sendRequest("api/auction/get-upcoming-auction", {}).then(function (response) {
              if (response.code === 1) {
                  $scope.upcomingAuctionList = response.data.data;
                  for (var x = 0; x < $scope.upcomingAuctionList.length; x++) {
                      //$scope.auctionList[x]['countdownTime'] = moment($scope.auctionList[x]['start_time']).toNow(true);
                      $scope.upcomingAuctionList[x]['countdownTime'] = moment($scope.upcomingAuctionList[x]['start_time']).fromNow();
                      ;
                  }
                  console.log($scope.upcomingAuctionList)
                  $scope.upcoming = true;
              } else {
                  $scope.upcomingAuctionList = [];
              }
              //$timeout($scope.getUpcomingAuction, 30000);
          });
      }*/
  /*    $scope.getPastAuction = function () {
          Masters.sendRequest("api/auction/get-past-auction", {}).then(function (response) {
              if (response.code === 1) {
                  $scope.pastAuctionList = response.data.data;
                  for (var x = 0; x < $scope.pastAuctionList.length; x++) {
                      $scope.pastAuctionList[x]['countdownTime'] = moment($scope.pastAuctionList[x]['start_time']).fromNow();
                  }
                  console.log("data");
                  $scope.past = true;
                  setTimeout(function () {
                      createCarousel("slider-two");
                      createCarousel("auctionJcarousel");
                      createCarousel("auctionJcarousel2");
                  }, 500);
                  //    setTimeout(function () {
                  //
                  //         // createCarousel("auctionJcarousel2");
                  //         createCarousel("auctionJcarousel3");
                  //     /!*setTimeout(function () {
                  //         $('#auctionJcarousel3').slick({
                  //             infinite: true,
                  //             slidesToShow: 3,
                  //             slidesToScroll: 3
                  //     });
                  //     },500)*!/
                  // }
              } else {
                  $scope.pastAuctionList = [];
              }
          });
      }*/
  $scope.getShortlistedAuctions = function () {
    if ($rootScope.userData['Id']) {
      $rootScope.userShortlistedDB = [];
      $rootScope.globalUserSelectedList = {};
      Masters.sendRequest("web/auction/get-user-shortlist-data", {
        user_id: parseInt($rootScope.userData['Id'])
        //user_id: 1
      }).then(function (response) {
        console.log(response);
        if (response.code == 1) {
          $rootScope.userShortlistedDB = response.data;
          for (var z = 0; z < response.data.length; z++) {
            populateAuctionItemList(response.data[z].auction_id)
          }
        }
      });
    }
  }
  $scope.getAuctionLists();
  var timer = $scope.getCurrentAuctions();
  //$scope.getPastAuction();
  //$scope.getUpcomingAuction();
  $scope.getShortlistedAuctions();

  $scope.goToAuctionScreen = function (auction_id) {
    $("#custom-loader").show();
    //$state.go("charts", {id: auction_id})
    $state.go("charts")
  };

  var modalOpen = false;
  Mousetrap.bind('alt+n', function () {
    $scope.OpenCustomSelection();
  });

  Mousetrap.bind('right', function () {
    $('.jcarousel-control-next').click();
  });
  Mousetrap.bind('left', function () {
    $('.jcarousel-control-prev').click();
  });

  $("body").on("click", ".show_auction_list", function (event) {
    populateAuctionItemList(this.id)
    event.stopImmediatePropagation();
    $("#modalList").openModal();
    $("#lean-overlay:last").css({
      "z-index": 1000
    });
    $("#modalList").css({
      "z-index": 1001
    });
  });

  function populateAuctionItemList(id) {
    $rootScope.currentAuctionID = id;
    console.log($rootScope.globalUserSelectedList)
    console.log($rootScope.currentAuctionID)
    $('#shortlistAll').prop('checked', false);
    if ($rootScope.globalUserSelectedList == undefined || !$rootScope.globalUserSelectedList['auction_' + id]) {
      Masters.sendRequest("web/auction/get-auction-items", {
        AuctionId: parseInt(id),
      }).then(function (response) {
        console.log(response)
        if (response.code === 1) {
          if ($rootScope.globalUserSelectedList == undefined) {
            $rootScope.globalUserSelectedList = {};
          }
          $rootScope.globalUserSelectedList['auction_' + id] = [];
          for (var i = 0; i < response.data.length; i++) {
            response.data[i]['base_price'] = convertPaiseToRupees(response.data[i]['base_price']);
            response.data[i]['bid_limit'] = convertPaiseToRupees(response.data[i]['bid_limit']);
            response.data[i]['max_price_inc'] = convertPaiseToRupees(response.data[i]['max_price_inc']);
            response.data[i]['reserve_price'] = convertPaiseToRupees(response.data[i]['reserve_price']);
            response.data[i]['tick_size'] = convertPaiseToRupees(response.data[i]['tick_size']);
            response.data[i]['is_shortList'] = false;
            angular.forEach($rootScope.userShortlistedDB, function (shortlistitem) {
              if (shortlistitem.auction_item_id == response.data[i]['auction_item_id']) {
                response.data[i]['is_shortList'] = true;
              }
            })
          }
          $rootScope.globalUserSelectedList['auction_' + id] = response.data;
        }
      });
    }
    $rootScope.$applyAsync()
    //$scope.safeApply();

  }

  $scope.$watch('globalUserSelectedList', function (lists) {
    $scope.Selectedcount = 0;
    angular.forEach(lists, function (listItem) {
      angular.forEach(listItem, function (listItems) {
        if (listItems.is_shortList) {
          $scope.Selectedcount += 1;
          //alert($scope.Selectedcount);
        }
      })
    })
  }, true);

  $scope.checkAll = function () {
    if ($('#shortlistAll').prop('checked')) {
      angular.forEach($scope.globalUserSelectedList['auction_' + $rootScope.currentAuctionID], function (user) {
        user.is_shortList = true;
      });
    } else {
      angular.forEach($scope.globalUserSelectedList['auction_' + $rootScope.currentAuctionID], function (user) {
        user.is_shortList = false;
      });

    }
  }

  $scope.goToAuction = function () {
    $scope.userShortlistedAuctionItems = [];
    var state = false;
    if (Object.keys($rootScope.globalUserSelectedList).length > 0) {
      console.log($rootScope.globalUserSelectedList)
      for (var key in $rootScope.globalUserSelectedList) {
        for (var i = 0; i < $rootScope.globalUserSelectedList[key].length; i++) {
          if ($rootScope.globalUserSelectedList[key][i]['is_shortList'] != undefined && $rootScope.globalUserSelectedList[key][i]['is_shortList'] == true) {
            $scope.userShortlistedAuctionItems[$rootScope.globalUserSelectedList[key][i]['id']] = $rootScope.globalUserSelectedList[key][i]
            console.log("triggered same cut off");
            state = true;
          }
        }
        console.log($scope.userShortlistedAuctionItems)
      }
      if (state) {
        setUserShortlistToDb($rootScope.globalUserSelectedList)
        localStorage.userAuctionItemShortlistData = JSON.stringify($rootScope.globalUserSelectedList);
        $state.go("charts")
      } else {
        alert("please shortlist atleast one auction")
      }
    } else {
      alert("please shortlist atleast one auction")
    }
  }
  $scope.OpenCustomSelection = function () {
    if (modalOpen == false) {
      modalOpen = true;
      $('#modal1').openModal({
        dismissible: false
      });
      setTimeout(function () {
        createCarousel("modalJcarousel");
      }, 500);
    } else {
      modalOpen = false;
      $('#modal1').closeModal();
    }
  }

  $scope.safeApply = function (fn) {
    if (this.$root) {
      var phase = this.$root.$$phase;
      if (phase == '$apply' || phase == '$digest') {
        if (fn && (typeof (fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    }
  };

  function setUserShortlistToDb(data) {
    console.log(data);

    $scope.submitUserShortlist = [];
    $rootScope.userShortlistedDB = [];
    for (var key in data) {
      for (var x = 0; x < data[key].length; x++) {
        $scope.submitUserShortlist[x] = {}
        $scope.submitUserShortlist[x]['auction_id'] = parseInt(data[key][x]['auction_id']);
        $scope.submitUserShortlist[x]['auction_item_id'] = parseInt(data[key][x]['auction_item_id']);
        $scope.submitUserShortlist[x]['user_id'] = parseInt($rootScope.userData['Id']);
        $scope.submitUserShortlist[x]['shortlist'] = data[key][x]['is_shortList'];

      }
    }
    console.log($scope.submitUserShortlist);
    if ($scope.submitUserShortlist.length > 0) {
      Masters.sendRequest("web/auction/set-user-shortlist-data", {
        user_selected: JSON.stringify($scope.submitUserShortlist)
      }).then(function (response) {
        console.log(response);
        if (response.code == 1) {
          //alert(response.message)
          console.log(response.message);
        }
      });
    }
  }

  $scope.logout = function () {
    //ws.close();
    //localStorage.clear();
    if ($rootScope.globalUserSelectedList && Object.keys($rootScope.globalUserSelectedList).length > 0) {
      setUserShortlistToDb($rootScope.globalUserSelectedList)
    }
    $rootScope.globalUserSelectedList = {};
    if ($rootScope.userData) {
      $rootScope.userData.JWToken = "";
      localStorage.userData = JSON.stringify($rootScope.userData);
    }
    $rootScope = $rootScope.$new(true);
    $scope = $scope.$new(true);
    // $http.defaults.headers.common.Authorization = '';
    //$window.localStorage.userData.JWToken = ""
    Masters.sendRequest("web/bidder/logout", {}).then(function (response) {
      window.location.href = "/app"
    });
  };

  function convertRupeesToPaise(x) {
    return x * 100;
  }

  function convertPaiseToRupees(x) {
    return x / 100;
  }

  $scope.$on("$destroy", function () {
    if (timer) {
      $timeout.cancel(timer);
    }
  });

  $scope.convertDate = function (date) {
    return moment(moment(date).utc()).format("DD-MM-YYYY HH:mm:ss");
  }
});
