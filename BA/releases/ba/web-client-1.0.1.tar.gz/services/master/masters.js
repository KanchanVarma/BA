(function () {
  'use strict';

  function getCookieValue(a) {
    var b = document.cookie.match('(^|[^;]+)\\s*' + a + '\\s*=\\s*([^;]+)');
    return b ? b.pop() : '';
  }

  function getToken() {
    let token = getCookieValue("_xsrf");
    if (typeof getCookieValue('_xsrf') != "undefined") {
      token = token.split('|');
      return atob(token [0]);
    }
    return "";
  }

  function Masters($http, $q, $state) {
    return {
      name: 'masters',
      sendRequest: function (path, parameters) {
        var deferred = $q.defer();
        var transform = function (data) {
          return $.param(data);
        };
        // parameters['_xsrf'] = getCookieValue('_xsrf');
        // alert(getCookieValue('_xsrf'));
        $http.post(path, parameters, {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Xsrftoken': getToken()
          },
          withCredentials: true,
          transformRequest: transform
        }).success(function (response) {
          if (response.code == 5) {
            window.location.href = "/app"
            // $state.go("login")
            return;
          }
          if (response.code == 6) {
            window.location.href = "/app"
            // $state.go("login")
            return;
          }
          deferred.resolve(response);
        }).error(function (response) {
          deferred.reject(response);
        });
        return deferred.promise;
      },
      get: function (path, parameters) {
        var deferred = $q.defer();
        var transform = function (data) {
          return $.param(data);
        };
        // parameters['_xsrf'] = getCookieValue('_xsrf');
        // alert(getCookieValue('_xsrf'));
        $http.get(path, parameters, {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Xsrftoken': getToken()
          },
          withCredentials: true,
          transformRequest: transform
        }).success(function (response) {
          if (response.code == 5) {
            window.location.href = "/app"
            // $state.go("login")
            return;

          }
          if (response.code == 6) {
            window.location.href = "/app"
            // $state.go("login")
            return;
          }
          deferred.resolve(response);
        }).error(function (response) {
          deferred.reject(response);
        });
        return deferred.promise;
      }
    };
  }

  app.factory('Masters', Masters);

  Masters.$inject = ['$http', '$q', '$state'];

})();
