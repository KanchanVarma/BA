var app = angular.module('GenericAuction', ['ui.router', 'angular.filter', 'datatables', 'datatables.buttons', 'QuickList']).run(function () {
    window._alert = window.alert;
    delete window.alert
    window.alert = function (message) {
        $("#modal1Alert").openModal({
            dismissible: false
        });
        $("#promptAlertContent").text(message)
    }
});
