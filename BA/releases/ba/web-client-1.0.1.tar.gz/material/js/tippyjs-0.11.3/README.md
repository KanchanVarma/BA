# Tippy.js

Tippy.js is a lightweight, pure JS tooltip library powered by Popper.js.

View the documentation and demo here: https://atomiks.github.io/tippyjs/

## Installation

See releases for the CSS and JS files needed: https://github.com/atomiks/tippyjs/releases

It's also available on npm:
```
npm install --save tippy.js
```


