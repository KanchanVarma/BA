export default {
    entry: './main.js',
    dest: './docs/tippy/tippy.js',
    format: 'umd',
    moduleName: 'Tippy'
}
