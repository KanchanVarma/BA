import './src/scss/tippy.scss'
import Tippy from './src/js/tippy.js'

export default Tippy
