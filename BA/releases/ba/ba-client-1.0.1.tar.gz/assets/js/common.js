var proposalStep = 1;
var pageName =""; 
var stepSelected = "";
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
	$('.tooltipOver').tooltip({ trigger: "hover" });
	
	$(".inboxTab ul li").click(function(){
		$(this).parent().find(".active").removeClass("active");
		$(this).addClass("active");
		$(".inboxWidgetList").hide();
		$("#inbox_"+$(this).attr('rel')).fadeIn();
	});
	
	$(".tabsListMenu li input[type='checkbox']").click(function(){
		var counts = 0;
		$(".tabsListMenu li input[type='checkbox']").each(function(){
			if($(this).is(":checked")){
				counts++;
			}
			if(counts > 3){
				$(this).prop('checked', false); 
				var popupHeading = "No response"; 
				var alertMsg = "<ul><li>Please select Three Options only.</li></ul>";
				var submitBtnValue = "Ok, Got It";
				var submitBtnId = "oldSiteBtn";
				var cancelButton= "no";
				var cancelBtnValue = "Old Site";
				var iconClass = "alertSpan";   
				popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
			}
		});
	});
	$("#homePageBtn").click(function(){
		window.open('index.html','_self');
	});
	$(".dateP").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true
	});
	$("#jumpOnpage").change(function(){
		window.open($(this).val(),'_self');
	});
	$(".monthYearP").datepicker( {
		format: "M-yyyy",
		viewMode: "months", 
		minViewMode: "months",
		autoclose: true
	});
	$(".datePickerbtn").click(function(){
		$(".dateP", $(this).closest(".form-group")).focus();
	});
	$(".timePickerbtn").click(function(){
		$(".timeP", $(this).closest(".form-group")).focus();
	});
	$(".menuOnBottomOpenContenor button").click(function(){
		$(this).parent().find(".active").removeClass("active");
		$(this).addClass("active");
	});
	$("#megaMenu").click(function(){
		$(".megaMenu").fadeIn('fast');
		setTimeout(function(){
			$(".containerTop").css({"opacity" : "1" , "margin-top":"0"});
			$(".containerBottom").css({"opacity" : "1" , "margin-top":"0"});
		}, 100);
	});
	
	$(".megaMenuFadeDiv").click(function(){
		$(".megaMenuSearchOpen").slideUp();
		$(".menuOnTop li:first-child").click();
		$(".menuOnBottomOpen").slideUp();
		$(".menuOnBottom li.active").removeClass('active');
	});
	
	$(".megaMenu #closeBtn").click(function(){
		$(".containerTop").css({"opacity" : "0.3" , "margin-top":"-20px"});
		$(".containerBottom").css({"opacity" : "0.3" , "margin-top":"60px"});
		$(".megaMenu").fadeOut();
	});
	$(".megaMenuSearchOpen #closeListDiv").click(function(){
		$(".megaMenuSearchOpen").slideUp();
	});
	$(".megaMenuSearch").click(function(){
		$(".megaMenuFadeDiv").click();
		$(".megaMenuSearchOpen").slideDown();
	});
	
	$(".menuOnTop li").click(function(){
		var currentTab = $(this).attr('rel');
		if(currentTab !=""){
			$(this).parent().find('.active').removeClass('active');
			if($(this).index() != 0){
				$(this).addClass('active');
				//$(".fadeDiv").show();
			}
			$(".menuOnTopOpen").hide();
			$("#"+currentTab).slideDown().css('min-height', '220px');
		}
		$(".megaMenuSearchOpen").hide();
		$(".menuOnBottomOpen").hide();
		$(".menuOnBottom li.active").removeClass('active');
	});
	$(".menuOnBottom li").click(function(){
		$(this).parent().find(".active").removeClass("active");
		$(this).addClass("active");
		if($(this).attr('rel') == "health"){
			$(".menuOnBottomOpen").slideDown();
			$("#healthStep_1").show();
		}else{
			$(".menuOnBottomOpen").slideUp();
		}
		$(".megaMenuSearchOpen").hide();
		$(".menuOnTopOpen").hide();
		$(".menuOnTop li").removeClass('active');
	});
	$("#healthStep_1 button").click(function(){
		$("#healthStep_1").hide('slide',{direction:'left'},300);
		$("#healthStep_2, .menuOnBottomOpenHeader").fadeIn();
		$(".bootstrap-tagsinput span").removeClass('active');
		$(".bootstrap-tagsinput span:nth-child(1)").css({'opacity':'1', 'margin-left':'0'}).html($(this).text() + '<span data-role="remove"></span>').addClass('active');
	});
	$("#healthStep_2 button").click(function(){
		$("#healthStep_2").hide('slide',{direction:'left'},300);
		$("#healthStep_3").fadeIn();
		$(".bootstrap-tagsinput span").removeClass('active');
		$(".bootstrap-tagsinput span:nth-child(2)").css({'opacity':'1', 'margin-left':'0'}).html($(this).text() + '<span data-role="remove"></span>').addClass('active');
		stepSelected = $(this).attr('rel');
	});
	$("#healthStep_3 button").click(function(){
		$("#healthStep_3").hide('slide',{direction:'left'},300);
		$("#step_4").fadeIn();
		$(".bootstrap-tagsinput span").removeClass('active');
		$(".bootstrap-tagsinput span:nth-child(3)").css({'opacity':'1', 'margin-left':'0'}).html($(this).text() + '<span data-role="remove"></span>').addClass('active');
		if(stepSelected == "quote"){
			window.open('quote.html','_self');
		}else{
			var linkPage = $(this).attr('rel');
			window.open(linkPage,'_self');
		}
		
	});
	$("#step_4 button").click(function(){
		$(".bootstrap-tagsinput span").removeClass('active');
		$(".bootstrap-tagsinput span:nth-child(4)").css({'opacity':'1', 'margin-left':'0'}).html($(this).text() + '<span data-role="remove"></span>').addClass('active');
		var linkPage = $(this).attr('rel');
		//window.open(linkPage,'_self');
	});
	$(".menuOnBottomOpenHeader .tag").click(function(){
		$(".menuOnBottomOpenContenor").hide('slide',{direction:'left'},300);
		$(".bootstrap-tagsinput span").removeClass('active');
		$("#"+$(this).attr('rel')).fadeIn();
		$(this).addClass('active');
		$(this).nextAll('.tag').css({'opacity':'0', 'margin-left':'-30px'});
	});
	
	$(".modalWidgetList li.add").click(function(){
		$(this).toggleClass("active");
	});
	$("#gstFeildGroup button").click(function(){
		if($(this).text().trim() == 'Yes'){
			$("#gstFeild").fadeIn();
		}else{
			$("#gstFeild").fadeOut();
		}
	})
	$(".serchbyIcon li").click(function(){
		$(this).parent().find('.active').removeClass("active");
		$(this).addClass('active');
		$("#searchByLabel").text("Search by "+$(this).attr('rel'));
	});
	$(document).on("click", ".popover .closePopover, #agentCodeUpdate", function() {
		//$("[aria-expanded='false']").attr('aria-expanded','true');
		//$(this).parents('.rightTagOnPageTitle').removeClass('open');
		$(this).parents(".popover").popover('hide');
	});
	$(".healthSummaryBarOnstepLeft").click(function(){
		summaryNotLastStep();
	});	
	$('.userAgent[rel=popover]').popover({ 
	  html : true, 
	  content: function() {
		return $('#popover_content_wrapper').html();		
	  }
	});
	$('.changePolicyDate[rel=popover]').popover({ 
	  html : true, 
	  content: function() {
		return $('#popover_content_wrapper2').html();		
	  }
	});
	$('.copyProposalIconPopover[rel=popover]').popover({ 
	  html : true, 
	  content: function() {
		return $('#popover_content_wrapper3').html();		
	  }
	});
	$(".chooseModelBrands li").click(function(){
		$(".chooseModelBrands li").removeClass('active');
		$(this).addClass('active');
		
		$(".modal-dialog-Model").css('width','950');
		$(".selectVariantGroup").css('display','inline-block');
		setTimeout (function(){
			$(".selectVariantGroupOpen").show('slide',{direction:'right'},300);
		}, 500);
		$("#chooseModelLabel label:first-child").text($(this).text());
	});
	$(".chooseModelVariant li").click(function(){
		$(".chooseModelVariant li").removeClass('active');
		$(this).addClass('active');
		$("#chooseModelLabel label:nth-child(2)").text($(this).text());
		
		$("#modelVariantFeild").val($("#chooseModelLabel label").text()).parents(".form-group").removeClass('is-empty');
		$("#fuelTypeQuote").val("Petrol").parents(".form-group").removeClass('is-empty');
		$(".close").click();
	});
	
	$(".chooseRTOCities li").click(function(){
		$(".chooseRTOCities .active").removeClass("active");
		$(this).addClass("active");
		$(".chooseRTOCitiesOpen").slideUp()
		$(this).parent().next(".chooseRTOCitiesOpen").slideDown();
	});
	$(".chooseRTOCitiesOpen li").click(function(){
		$("#rtoLocationFeild").val($(this).text()).parents(".form-group").removeClass('is-empty');
		$(".close").click();
	});
	$(".btn-switch").click(function(){
		$(this).parent().find(".btn-switch").removeClass("active");
		$(this).addClass("active");
		$(this).parent().find('input[type="hidden"]').val($(this).text());
	});
	
	// $(".stepTags li a").click(function(){
	// 	if(!$(this).parents('li').hasClass('disabled') && !$(this).parents('li').hasClass('current')){
	// 		$(".stepTags li").removeClass('active current').removeClass('success');
	// 		$(this).parents('li').addClass('active current');
	// 		var currentTab = ($(this).parents('li').index() + 1);
	// 		for(i=1; i<currentTab; i++){
	// 			$(".stepTags li:nth-child("+ i +")").removeClass('active').addClass('success');
	// 		}
	// 		$(".formContainer").hide();
	// 		$("#"+ $(this).attr('rel')).slideDown('slow');
	// 		$("html,body").animate({ scrollTop: $('.mainSectionContainer').offset().top }, 'slow');
	// 		proposalStep = $(this).parents('li').index() + 1 ;
	// 		buttonsUpdate();
	//
	// 		if(proposalStep  ==4){
	// 			summaryLastStep();
	// 			$(".pageTitle").text('Sign Up');
	// 		}else{
	// 			summaryNotLastStep();
	// 			$(".pageTitle").text('Sign Up');
	// 		}
	// 	}
	// });
	
	$("#searchCustomerBtn").click(function(){
		if($("#searchCustomerFeild").val() == ""){
			var popupHeading = "No response"; 
			var alertMsg = "<ul><li>Please ender Aadhaar No.</li></ul>";
			var submitBtnValue = "Ok, Got It";
			var submitBtnId = "oldSiteBtn";
			var cancelButton= "no";
			var cancelBtnValue = "Old Site";
			var iconClass = "alertSpan";   
			popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
		}else{
			openOTPModal();
		}
	});
	$(".tabsListFilter input").click(function(){
		$("#searchByLabel").html("Search by "+ $(this).parent().text()+" <em class='text-danger'>*</em>");
	});
	$(".accordionTab .accordionTabHeader").click(function(){
		$(this).parents("li").toggleClass('active');
		$(this).parents("li").find(".accordionTabContainer").slideToggle();
	});
	$("#electricalAccBtn").click(function(){
		if($(this).is(":checked")){
			$("#electricalAccessories").slideDown();
			$("#nonElectricalAccTag").fadeIn();
		}else{
			$("#electricalAccessories").slideUp();
			$("#nonElectricalAccTag").fadeOut();
		}
	});
	$(".myDiaryWidget li span.deletIcon").click(function(){
		$(this).parents('li').remove();
	});
	
	$("#customerInfoCustDetails").click(function(){
		$(this).parent().find(".active").removeClass("active");
		$(this).addClass("active");
		$("html,body").animate({ scrollTop: $('#customerDetailsOpen').offset().top }, 'slow');	
	});
	$("#addInfoCustDetails").click(function(){
		$(this).parent().find(".active").removeClass("active");
		$(this).addClass("active");
		$("html,body").animate({ scrollTop: $('#addressCustomerDetails').offset().top }, 'slow');	
	});
	$(".pincodeFeildIcon").click(function(){
		$(this).parents(".boxDiv").find(".pincodeFeildOpen").slideDown();
	});
	$("#permanentAddBtn").click(function(){
		if(!$(this).is(":checked")){
			$("#permanentAddOpen").slideDown();
		}else{
			$("#permanentAddOpen").slideUp();
		}		
	});
	$(".megaMenuSearchDiv .inboxWidgetList li label.copy").click(function(){
		window.open('proposal.html#summaryStep','_slef');
	});
	// Inbox Page
	$(".inboxContainer table input[type='checkbox']").click(function(){
		if($(this).is(":checked")){
			$(".inboxSummaryBar").css({'bottom':'0','opacity':'1'});
			$(".inboxSummaryBar .counts").text(parseInt($(".inboxSummaryBar .counts").text()) + 1);
			$(this).parents('tr').addClass('activeTR');
		}else{
			$(".inboxSummaryBar .counts").text(parseInt($(".inboxSummaryBar .counts").text()) - 1);
			if($(".inboxSummaryBar .counts").text() == 0){
				$(".inboxSummaryBar").css({'bottom':'-30px','opacity':'0'});
			}
			$(this).parents('tr').removeClass('activeTR');
		}
	})
	$("#rgiclPolicyRenewalSearch").click(function(){
		if($("#rgiclPolicyRenewalSearchFeild").val() != ""){
			$(".rgiclPolicyModel").fadeIn();
		}else{
			var popupHeading = "No response"; 
			var alertMsg = "<ul><li>Please enter policy number</li></ul>";
			var submitBtnValue = "Ok, Got It";
			var submitBtnId = "oldSiteBtn";
			var cancelButton= "no";
			var cancelBtnValue = "Old Site";
			var iconClass = "alertSpan";   
			popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
		}
	});
	$("#renewalValidate").click(function(){
		$('#renewalPolicy').modal('hide');
		$(".stepTags li:nth-child(5) a").click();
		buttonsUpdate();
	});
	$("#vehicleDetailsFetch").click(function(){
		$('#renewalPolicy').modal('hide');
		$(".stepTags li:nth-child(2) a").click();
		$("#searchVehicleFeild").val("MH").parents(".form-group").removeClass("is-empty");
		searchVehicleBtn();
		buttonsUpdate();
	});
	$("#newVehicle").click(function(){
		if($(this).is(":checked")){
			$("#vehicleDetailsTabOpten .registrationNoFeild, .formContainer.Quote .registrationNoFeild").attr('disabled','disabled');
			$(".registrationNoFirstFeild").val('New');
			$("#vehicleDetailsSearchOpen").slideDown();
			$("#vehicleDetailsSearchOpenBtn").slideDown();
			$("#vehicleDetailsSearchOpen, #vehicleDetailsSearchOpenBtn").slideDown();
			$("#searchVehicleFeild").val('New');
			$("#vehicleDetailsSearchOpen .form-control").val('');
			$("#vehicleDetailsSearchOpen .form-group").addClass('is-empty');
		}else{
			$(".registrationNoFeild").removeAttr('disabled','disabled');
			$(".registrationNoFirstFeild").val('');
		}
	});
	$("#shareBtns span").click(function(){
		$(this).parents('#shareBtns').find('.active').removeClass('active');
		$(this).parent().addClass('active');
		$(".shareBtnOpen").slideDown();
		$("#shareBtnLabel").text($(this).parent().find('label').attr('rel'));
	})
	$("#inspectionLeadID").blur(function(){
		$("#inspectionLeadID1").val('').removeClass('is-empty');
		$("#inspectionLeadID2").val('10:45am').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID3").val('24-11-2017').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID4").val('MH').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID5").val('04').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID6").val('JC').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID7").val('4005').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID8").val('Ch000102563254001').parents('.form-group').removeClass('is-empty');
		$("#inspectionLeadID9").val('Eng125478521452').parents('.form-group').removeClass('is-empty');
	});
	$("#vehicleHypothecated").click(function(){
		if($(this).is(":checked")){
			$("#vehicleHypothecatedOpen").slideDown();
		}else{
			$("#vehicleHypothecatedOpen").slideUp();
		}
	});
	$("#trailerAttached").click(function(){
		if($(this).is(":checked")){
			$("#trailerAttachedOpen").slideDown();
		}else{
			$("#trailerAttachedOpen").slideUp();
		}
	});
	$("#addressOnOthersTab button").click(function(){
		var currentText = $(this).text().trim();
		if(currentText == 'Other'){
			$("#addressOnOthersTabOpen").fadeIn();
		}else{
			$("#addressOnOthersTabOpen").fadeOut();
		}
	})
	$("#idv1, #idv2").keyup(function(){
		if($(this).val() ==""){
			$(this).val(0);
		}
		$("#idvTotal").val(parseInt($("#idv1").val()) + parseInt($("#idv2").val())).parents('.form-group').removeClass('is-empty');
	});
	$("#customerTypeChoose button").click(function(){
		if($(this).text().trim() == "Individual"){
			$("#companyDetails").fadeOut();
			$("#individualCustomerDetails").fadeIn();
		}else{
			$("#companyDetails").fadeIn();
			$("#individualCustomerDetails").fadeOut();
		}
	});
	
	//payment
	$(".paymentModule li").click(function(){
		$(this).parents('ul').find(".active").removeClass('active');
		$(this).addClass("active");
		$(".listDataContainer").hide();
		$("#"+ $(this).attr('rel')).slideDown();
		var liLabel = $(this).text().trim().toLowerCase();
		if(liLabel == "ivr"){
			$("#paymentOnPaynow").text("Call Now");
		}else if(liLabel == "send link"){
			$("#paymentOnPaynow").text("Send Link");
		}else{
			$("#paymentOnPaynow").text("Pay Now");
		}
	});
	$(".deletePayOrder").click(function(){
		$(this).parents('.paymentOrder').slideUp();
	});
	$("#agentCustomerSwitch button").click(function(){
		if($(this).text().trim().toLowerCase() == "customer"){
			$(".paymentModule .agent").hide();
			$(".paymentModule .customer").css('display','inline-block');
		}else{
			$(".paymentModule .customer").hide();
			$(".paymentModule .agent").css('display','inline-block');
		}
		$(".paymentModule ."+ $(this).text().trim().toLowerCase()).eq(0).click();
	});
	$(".switch.yesNo").click(function(){
		if($(".switch-input").is(":checked")){
			$("#paymentOnPaynow").text("Add");
		}else{
			$(".paymentSectionTab").eq(0).slideUp();
			$(".paymentSectionTab").eq(1).slideUp();
			$("#paymentSectionTabDetails").slideDown();
			$("#paymentOnPaynow").text("Pay Now");
			
		}
	});
	$("#paymentOnPaynow").click(function(){
		if($(this).text() == "Add"){
			$(".paymentSectionTabLeftBorder").eq(0).slideDown();
			$("#paymentOnPaynow").text("Add ");
		}else if($(this).text() == "Add "){
			$(".paymentSectionTabLeftBorder").eq(1).slideDown();
			$("#paymentOnPaynow").text("Pay Now");
			$("#paymentSectionTabDetails").slideUp();
		}else{
			window.open('payment_Successful.html','_self');
		}
	});
	$("#inbox_tab1 th .filter").focus(function(){
		$(this).parents('tr').find(".active").removeClass('active');
		$(this).parents('.filterDiv').addClass('active');
		$(".filterDivFade").show();
	});
	$(".filterDivFade").click(function(){
		$("#inbox_tab1 th .filterDiv.active").removeClass('active');
		$(".filterDivFade").hide();
	});
	
});
function filterTable(){
	$("#inbox_tab1 th .filterDiv.active").removeClass('active');
	$(".filterDivFade").hide();
	setTimeout(function(){
		alert("Data updating...");
	},300);
}

function openPaymentSectionTabDetails(){
	$("#paymentSectionTabDetails").slideDown();
	$("#paymentOnPaynow").text("Add ");
}
function deletePaymentSectionTab(num){
	$(".paymentSectionTab").eq(num).slideUp();
	$("#paymentSectionTabDetails").slideDown();
	$("#paymentOnPaynow").text("Add");
}

// On Inbox panel add Tab functionality 
function tabdisplay(){
	$(".inboxTab ul li").hide();
	var addActive = false;
	$(".tabsListMenu li input").each(function(){
		if($(this).is(":checked")){
			var liIndex = $(this).parents("li").index();
			$(".inboxTab ul li:nth-child("+ (liIndex +1) +")").css('display','inline-block');
			if(addActive == false){
				$(".inboxTab ul li:nth-child("+ (liIndex +1) +")").addClass('active');
				addActive = true;
			}
		}
	});
	$(".inboxTab ul li.active").click();
}

// Add Widgets on floating button
function addWidgetsFloatingBtn(){
	$(".widgetHide").hide();
	$(".modalWidgetList li.add").each(function(){
		if($(this).hasClass('active')){
			var widgetShow = $(this).attr('rel');
			$("#"+ widgetShow ).show();
		}
	});
}
function calculatePremium(ids){
	var formVaildation = true;
	$(".formContainer .required").each(function(){
		if($(this).val() == ""){
			formVaildation = false;
			var msg = $(this).attr('rel');
			$(this).next().after('<span class="errorIcon error" data-toggle="tooltip" title="'+  msg +'" data-placement="top"></span>').parents(".form-group").addClass('has-error');
			$('[data-toggle="tooltip"]').tooltip(); 
		}
	});
	if(formVaildation == true){
		$(".calculatePremium, .showonCalculatePrem, #coverDetailsQuote").slideDown();
		$("#"+ids.id).text('Recalculate Premium');
		$("html,body").animate({ scrollTop: $('#coverDetailsQuote').offset().top }, 'slow');	
		$(".btn-success").focus();
		$(".pageTitle").text("Quote No. - Q1200000012456");
	}else{
		$(".required").click(function(){
			$(this).parents(".form-group").removeClass('has-error');
			$(this).parents(".form-group").find(".errorIcon").remove();
		});
	}
}

// Alert Window  ********************************************************
function popupWindowCommon(popupHeading,popupMessage,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass){
	var popupbody = '<div class="successMsg-popup"><div class="popup-heading-div"><span class="'+iconClass+'"></span><label>'+popupHeading+'</label> <div class="closeButton">&#10005;</div></div><div>';
	popupbody += '<div class="msgDiv">'+popupMessage+'</div></div>' ;
	popupbody += '<div class="msgFooter"><input id="'+submitBtnId+'" type="button" value="'+submitBtnValue+'" class="btn btn-primary cancelBtn" />'; 
	
	if(cancelButton == 'yes'){
		popupbody += '&nbsp; <input type="button" value="'+cancelBtnValue+'" class="btn borderBtn cancelBtn cancelBtnEvent" />';
	}
	
	popupbody += '<div></div>';
	var popupbodyBG = '<div class="TransparentBg"></div>';
	$("body").append(popupbody);
	$("body").append(popupbodyBG);
	
	$(".successMsg-popup .btn, .successMsg-popup .closeButton").click(function(){
		$('.successMsg-popup, .TransparentBg').remove();
	});
}

function aadhaarCardDontHave(){
	$("#customerDetailsOpen").slideDown();
	$("html,body").animate({ scrollTop: $('#searchCustomerFeild').offset().top }, 'slow');	
	$("#customerDetailsOpen input[type='text'], #customerDetailsOpen input[type='number'], #customerDetailsOpen select,  #customerDetailsOpen textarea").each(function(){
		$(this).val(" ").parents(".form-group").addClass("is-empty");
	});
	$(".customerNameEdit").hide();
	$("#customerName").show();
	
}
// Next button on Proposal Screen 
var documentUploaded = false;
function nextBtn(){
	if(proposalStep == 12 && documentUploaded == false){
		var popupHeading = "Confirmation Alert"; 
		var alertMsg = "<ul><li>Do you want to upload documents? </li></ul>";
		var submitBtnValue = "Yes";
		var submitBtnId = "documentUploadYes";
		var cancelButton= "yes";
		var cancelBtnValue = "No";
		var iconClass = "alertSpan";   
		popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
		
		$("#documentUploadYes").click(function(){
			$("#uploadDocumentSection").fadeIn();
			documentUploaded = true;
		});
		$(".cancelBtnEvent").click(function(){
			proposalStep++ ;
			$(".stepTags li:nth-child("+ proposalStep +")").removeClass('disabled');
			$(".stepTags li:nth-child("+ proposalStep +") a").click();
			buttonsUpdate();
		});
	}else{
		proposalStep++ ;
		$(".stepTags li:nth-child("+ proposalStep +")").removeClass('disabled');
		$(".stepTags li:nth-child("+ proposalStep +") a").click();
		buttonsUpdate();
	}
}
function backBtn(){
	proposalStep--;
	$(".stepTags li:nth-child("+ proposalStep +") a").click();
	buttonsUpdate();
}
function buttonsUpdate(){
	//alert(proposalStep);
	if(proposalStep > 1){
		$("#backBtnBottom").show();
		$(".copyProposalIconPopover").fadeOut();
	}else{
		$("#backBtnBottom").hide();
		$(".copyProposalIconPopover").fadeIn();
	}
	var btnValues = ['Other Details','Contact Details','View Details', 'Submit'];
	$("#nextBtnBottom").text(btnValues[(proposalStep - 1)]);
	
	if(proposalStep > 2 && proposalStep < 3){
		//setTimeout(function(){
			//$(".motorSummaryBar").css({'bottom':'0', 'opacity':'1'});
		//}, 500);
	}
	if(proposalStep == 4){
		$("#addDiscrepancyBtn").show();
	}else{
		$("#addDiscrepancyBtn").hide();
	}
	if(proposalStep == 4 && pageName == "BFS"){
		$("#nextBtnBottom").text("Submit");
	}
	if(proposalStep == 4 && pageName == "UW"){
		$("#nextBtnBottom").text("UW Details");
		$("#proposalTbladd").show();
	}
}
function summaryEdit(liIndex){
	$(".stepTags li:nth-child("+ liIndex +") a").click();
}
function summaryLastStep(){
	$(".stepTags").addClass('hideStep');
	$(".healthSummaryBarOnstep").addClass('open');
	$(".motorSummaryBar").css({'bottom':'-50', 'opacity':'0'});
	$(".mandatoryEs").hide();
}
function summaryNotLastStep(){
	$(".stepTags").removeClass('hideStep');
	$(".healthSummaryBarOnstep").removeClass('open');
	$(".mandatoryEs").show();
}
function searchVehicleBtn(buttonType){
	if($("#searchVehicleFeild").val() != ""){		
		$("#modelVariantFeild").val('MARUTI SUZUKI 800 5 STR 796 CC').parents(".form-group").removeClass('is-empty');
		$("#fuelTypeQuote").val('Petrol').parents(".form-group").removeClass('is-empty');
		$("#rtoLocationFeild").val('Thane	MH04').parents(".form-group").removeClass('is-empty');
		$("#vehicleDetailsSearchOpen, #vehicleDetailsSearchOpenBtn").slideDown();
		
	}else if(buttonType =="regNot"){
		$("#vehicleDetailsSearchOpen, #vehicleDetailsSearchOpenBtn").slideDown();
		$("#searchVehicleFeild").val('');
		$("#vehicleDetailsSearchOpen .form-control").val('');
		$(".form-group").addClass('is-empty');
	}else{
		var popupHeading = "No response"; 
		var alertMsg = "<ul><li>Please enter retgistration number</li></ul>";
		var submitBtnValue = "Ok, Got It";
		var submitBtnId = "oldSiteBtn";
		var cancelButton= "no";
		var cancelBtnValue = "Old Site";
		var iconClass = "alertSpan";   
		popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
		$("#searchVehicleFeild").focus();
	}
}

function loginWindow(){
	$('#loginModal').modal('show');
	$(".modal-dialog").css('width','800px')	
	$(".loginDivModel").show();
	$(".forgotPasswordDiv").hide();
	$(".changeYourPassword").hide();
}
function closeModal(){
	$('#loginModal, #share, #print').modal('hide');	
}
function loginContinue(){
	$(".loginDivModel").hide();
	$(".changeYourPassword").show();
	$(".modal-dialog").css('width','500px')
}
function sendLinkLogin(){
	$(".loginDivModel").show();
	$(".forgotPasswordDiv").hide();
	$(".modal-dialog").css('width','800px')
}
function forgotPassword(){
	$(".loginDivModel").hide();
	$(".forgotPasswordDiv").show();
	$(".modal-dialog").css('width','500px')
}
function calcMocelOpen(){
	$('#calendarTargetModal').modal('show');
}
function openCalendarOther(){
	$("#calendarTbl1").hide();
	$("#calendarTbl2").slideDown();
}
function openCalendarback(){
	$("#calendarTbl2").hide();
	$("#calendarTbl1").slideDown();
}

function trailerCloseModal(){
	$("#trailerTable").fadeIn();
	$('#addTrailer').modal('hide');	
}
function addDiscrepancies(){
	$('#addDiscrepancy, #addDiscrepancy2').modal('hide');
	$("#proposalTbladd").show();
}
function openOTPModal(){
	$('#OTP').modal('show');	
}
function OTPModalClose(){
	$('#OTP').modal('hide');
	$("#customerDetailsOpen").slideDown();
	$("html,body").animate({ scrollTop: $('#searchCustomerFeild').offset().top }, 'slow');	
}
function inactiveModal(){
	$('#inactiveDashboard').modal('show');	
}
function inactiveModalClose(){
	$('#inactiveDashboard').modal('hide');	
}
function uploadDcumentsModalClose(){
	$('#uploadDcuments').modal('hide');	
}
function manappuramClick(){
	var popupHeading = "Redirecting"; 
	var alertMsg = "<ul><li>Redirecting for Manappuram payment Gateway ...</li></ul>";
	var submitBtnValue = "Ok";
	var submitBtnId = "oldSiteBtn";
	var cancelButton= "no";
	var cancelBtnValue = "Old Site";
	var iconClass = "alertSpan";   
	popupWindowCommon(popupHeading,alertMsg,submitBtnValue,submitBtnId,cancelButton,cancelBtnValue,iconClass);
}
function openCustomerComplaints(){
	$("#openCustomerComplaints").slideDown();
}
function sendMailPolicy(){
	$("#openCustomerComplaints").slideUp();
}